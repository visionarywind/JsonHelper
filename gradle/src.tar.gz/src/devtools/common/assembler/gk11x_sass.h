/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: gk110_sass.h
 *
 *   Description:
 *       A partial set of GK110 SASS instruction macros. Primary
 *       client is the GK110 SASS Assembler.
 *
 ******************************************************************************/

#ifndef _GK110_SASS_H
#define _GK110_SASS_H

#include "bitfields.h"

/* GK110 ISA bitfields

   Terminology: as the 32-bit instruction is the exception and 64-bit
   is the normal case, 32-bit relevant identifiers will be called out
   with GK110SASS32_ whereas GK110SASS_ is use when it applies to 64-bit or
   when the bitness is irrelevant.
*/

/* Opcode is split between bottom two bits and some top bits:
   Instruction = PrefixRest SubOpcode ..... PrefixStart

   Unfortunately we have to distinguish based on the length of the
   opcode. Adding to the confusion is the fact that the two top bits
   of the opcode is stored at the bottom. */

// 3bit opcodes
#define    GK110SASS_OPCODE3__B20I         0x3

// 4bit opcodes
#define    GK110SASS_OPCODE4__MISC3        0xB  // TODO:  this could use a better name

// 5bit opcodes
#define    GK110SASS_OPCODE5__CTRL         0x00
#define    GK110SASS_OPCODE5__LOP32I       0x01
#define    GK110SASS_OPCODE5__FADD32I      0x02
#define    GK110SASS_OPCODE5__FFMA32I      0x03
#define    GK110SASS_OPCODE5__IMAD32I      0x04
#define    GK110SASS_OPCODE5__ISCADD32I    0x05
#define    GK110SASS_OPCODE5__LD           0x06
#define    GK110SASS_OPCODE5__ST           0x07
#define    GK110SASS_OPCODE5__VADD         0x08
#define    GK110SASS_OPCODE5__VADD2        0x09

// 6bit opcodes
#define    GK110SASS_OPCODE6__IADD32I      0x14
//                                         0x15
#define    GK110SASS_OPCODE6__TEX          0x16
#define    GK110SASS_OPCODE6__TLD4         0x17
//                                         0x18
//                                         0x19
//                                         0x1A
//                                         0x1B
//                                         0x1C
#define    GK110SASS_OPCODE6__VADD4        0x1D
#define    GK110SASS_OPCODE6__VMNMX        0x1E
#define    GK110SASS_OPCODE6__VMNMX2       0x1F
#define    GK110SASS_OPCODE6__VSET         0x20
#define    GK110SASS_OPCODE6__VSET2        0x21

// 7bit opcodes
#define    GK110SASS_OPCODE7__FMUL32I      0x44
#define    GK110SASS_OPCODE7__IMUL32I      0x45
#define    GK110SASS_OPCODE7__SULDGA       0x46
#define    GK110SASS_OPCODE7__SUSTGA       0x47
//                                         0x48
//                                         0x49
//                                         0x4A
//                                         0x4B
//                                         0x4C
#define    GK110SASS_OPCODE7__ATOM         0x4D
#define    GK110SASS_OPCODE7__MISC0        0x4E  // TODO: this could use a better name
#define    GK110SASS_OPCODE7__MISC1        0x4F  // TODO: this could use a better name
#define    GK110SASS_OPCODE7__MISC2        0x50  // TODO: this could use a better name
// ....

// GK110SASS_OPCODE3__B20I sub-opcodes
#define    GK110SASS_OPCODE3SUB3SUB4_HI        62:60
#define    GK110SASS_OPCODE3SUB3SUB4_LO        58:55
#define    GK110SASS_OPCODE3SUB3SUB4__ISETP    0x36
#define    GK110SASS_OPCODE3SUB3SUB5_HI        62:60
#define    GK110SASS_OPCODE3SUB3SUB5_LO        58:54
#define    GK110SASS_OPCODE3SUB3SUB5__IADD     0x82
#define    GK110SASS_OPCODE3SUB3SUB5__SHR      0x85
#define    GK110SASS_OPCODE3SUB3SUB5__LOP      0x88
#define    GK110SASS_OPCODE3SUB3SUB5__P2R      0x99
#define    GK110SASS_OPCODE3SUB3SUB5__R2P      0x9a
#define    GK110SASS_OPCODE3SUB3SUB5__BFE      0x80
#define    GK110SASS_OPCODE3SUB3SUB5__BFI      0x7e

// GK110SASS_OPCODE4__MISC3 sub-opcodes
#define    GK110SASS_OPCODE4SUB7               61:55
#define    GK110SASS_OPCODE4SUB7__ICMP         0x34
#define    GK110SASS_OPCODE4SUB7__ISET         0x35
#define    GK110SASS_OPCODE4SUB7__ISETP        0x36
#define    GK110SASS_OPCODE4SUB8               61:54
#define    GK110SASS_OPCODE4SUB8__IADD         0x82
#define    GK110SASS_OPCODE4SUB8__SHR          0x85
#define    GK110SASS_OPCODE4SUB8__FLO          0x86
#define    GK110SASS_OPCODE4SUB8__IMUL         0x87
#define    GK110SASS_OPCODE4SUB8__LOP          0x88
#define    GK110SASS_OPCODE4SUB8__SHL          0x89
#define    GK110SASS_OPCODE4SUB8__MOV          0x93
#define    GK110SASS_OPCODE4SUB8__P2R          0x99
#define    GK110SASS_OPCODE4SUB8__R2P          0x9A

// GK110SASS_OPCODE5__CTRL sub-opcodes
// TODO: All of these sub-ops need "OP_" prefixes to avoid namespace conflicts
//       when using the sass assembler.
#define    GK110SASS_OPCODE5SUB2               60:59
#define    GK110SASS_OPCODE5SUB2__SHINT        0x1
#define    GK110SASS_OPCODE5SUB6               60:55
#define    GK110SASS_OPCODE5SUB6__BPT          0x00
#define    GK110SASS_OPCODE5SUB6__JMX          0x20
#define    GK110SASS_OPCODE5SUB6__JMP          0x21
#define    GK110SASS_OPCODE5SUB6__JCAL         0x22
//                                             0x23
#define    GK110SASS_OPCODE5SUB6__BRA          0x24
#define    GK110SASS_OPCODE5SUB6__BRX          0x25
#define    GK110SASS_OPCODE5SUB6__CAL          0x26
#define    GK110SASS_OPCODE5SUB6__PRET         0x27
#define    GK110SASS_OPCODE5SUB6__PLONGJMP     0x28
#define    GK110SASS_OPCODE5SUB6__SSY          0x29
#define    GK110SASS_OPCODE5SUB6__PBK          0x2A
#define    GK110SASS_OPCODE5SUB6__PCNT         0x2B
#define    GK110SASS_OPCODE5SUB6__GETCRSPTR    0x2C
#define    GK110SASS_OPCODE5SUB6__GETLMEMBASE  0x2D
#define    GK110SASS_OPCODE5SUB6__SETCRSPTR    0x2E
#define    GK110SASS_OPCODE5SUB6__SETLMEMBASE  0x2F
#define    GK110SASS_OPCODE5SUB6__OP_EXIT      0x30
#define    GK110SASS_OPCODE5SUB6__LONGJMP      0x31
#define    GK110SASS_OPCODE5SUB6__RET          0x32
#define    GK110SASS_OPCODE5SUB6__KIL          0x33
#define    GK110SASS_OPCODE5SUB6__BRK          0x34
#define    GK110SASS_OPCODE5SUB6__CONT         0x35
#define    GK110SASS_OPCODE5SUB6__RTT          0x36
#define    GK110SASS_OPCODE5SUB6__SAM          0x37
#define    GK110SASS_OPCODE5SUB6__RAM          0x38
#define    GK110SASS_OPCODE5SUB6__IDE          0x39

#define    GK110SASS_OPCODE7SUB1               58:58
#define    GK110SASS_OPCODE7SUB1__TLD          0x0

// GK110SASS_OPCODE7__MISC[012] sub-opcodes
#define    GK110SASS_OPCODE7SUB3               58:56
#define    GK110SASS_OPCODE7SUB3__CCTL         0x03
#define    GK110SASS_OPCODE7SUB4               58:55
#define    GK110SASS_OPCODE7SUB4__MOV32I       0x08
#define    GK110SASS_OPCODE7SUB4__IPA          0x09
#define    GK110SASS_OPCODE7SUB4__TXD          0x0C
#define    GK110SASS_OPCODE7SUB4__ATOM_CAS     0x0F
#define    GK110SASS_OPCODE7SUB4__VSEL2        0x02
#define    GK110SASS_OPCODE7SUB4__TXD_B        0x0C
#define    GK110SASS_OPCODE7SUB4__IPA          0x09
#define    GK110SASS_OPCODE7SUB5               58:54
#define    GK110SASS_OPCODE7SUB5__SHFL         0x02
#define    GK110SASS_OPCODE7SUB5__SULDGA       0x06
#define    GK110SASS_OPCODE7SUB5__OP_LDL       0x08
#define    GK110SASS_OPCODE7SUB5__LDS          0x09
#define    GK110SASS_OPCODE7SUB5__STL          0x0A
#define    GK110SASS_OPCODE7SUB5__STS          0x0B
#define    GK110SASS_OPCODE7SUB5__LDC          0x12
#define    GK110SASS_OPCODE7SUB5__OP_S2R       0x19
#define    GK110SASS_OPCODE7SUB5__PSETP        0x12
#define    GK110SASS_OPCODE7SUB5__CSETP        0x14
#define    GK110SASS_OPCODE7SUB5__BAR          0x15
#define    GK110SASS_OPCODE7SUB5__NO_OP        0x16
#define    GK110SASS_OPCODE7SUB5__B2R          0x17
#define    GK110SASS_OPCODE7SUB5__VOTE         0x1B

// These fields are instruction specific
#define GK110SASS_LDC_CA16   38:23 // constant_address[16]
#define GK110SASS_LDC_CBANK5 43:39 // cbank[5]

#define GK110SASS_JMP_CA16   38:23 // constant_address[16]
#define GK110SASS_JMP_CBANK5 43:39 // cbank[5]

#define GK110SASS_LOP      45:44 // logical operation (non-32I format)
#define    GK110SASS_LOP__AND    0
#define    GK110SASS_LOP__OR     1
#define    GK110SASS_LOP__XOR    2
#define    GK110SASS_LOP__PASS_B 3

#define GK110SASS_BARSRCMODE 47:46
#define GK110SASS_BARSRCMODE__REGNAME_REGCOUNT 0x0
#define GK110SASS_BARSRCMODE__REGNAME_IMMCOUNT 0x1
#define GK110SASS_BARSRCMODE__IMMNAME_REGCOUNT 0x2
#define GK110SASS_BARSRCMODE__IMMNAME_IMMCOUNT 0x3

#define GK110SASS_BARMODE  37:35
#define    GK110SASS_BARMODE__SYNC    0
#define    GK110SASS_BARMODE__ARV     1
#define    GK110SASS_BARMODE__RED     2
#define    GK110SASS_BARMODE__SCAN    3
#define    GK110SASS_BARMODE__SYNCALL 4

#define GK110SASS_BARREDOP 39:38
#define    GK110SASS_BARREDOP__POPC 0
#define    GK110SASS_BARREDOP__AND  1
#define    GK110SASS_BARREDOP__OR   2

#define GK110SASS_B2RTYPE 36:35
#define    GK110SASS_B2RTYPE__BAR       0
#define    GK110SASS_B2RTYPE__RESULT    1
#define    GK110SASS_B2RTYPE__WARP      2
#define    GK110SASS_B2RTYPE__UNDEFINED 3

// Make this encoding a U8, even though the ISA says this is a U4
// This is to prevent an issue being hit on Fmodel. Silicon
// treats the upper 4 bits as dont cares. (Bug 945826).
// In particular, for B2R.WARP fmodel requires that this field
// be set to RZ. Silicon will entirely ignore the field.
#define GK110SASS_B2RNAME 17:10

#define GK110SASS_LOP_32I  57:56 // logical operation (32I format)
#define    GK110SASS_LOP_32I__AND    0
#define    GK110SASS_LOP_32I__OR     1
#define    GK110SASS_LOP_32I__XOR    2
#define    GK110SASS_LOP_32I__PASS_B 3

#define GK110SASS_BOP1  49:48  // Boolean operation for ISETP
#define    GK110SASS_BOP1__AND  0
#define    GK110SASS_BOP1__OR   1
#define    GK110SASS_BOP1__XOR  2

#define GK110SASS_BOP0  29:27
#define    GK110SASS_BOP0__AND  0
#define    GK110SASS_BOP0__OR   1
#define    GK110SASS_BOP0__XOR  2

#define GK110SASS_ATOM_OP    58:55   // atomic operation
#define    GK110SASS_ATOM_OP__ADD       0
#define    GK110SASS_ATOM_OP__MIN       1
#define    GK110SASS_ATOM_OP__MAX       2
#define    GK110SASS_ATOM_OP__INC       3
#define    GK110SASS_ATOM_OP__DEC       4
#define    GK110SASS_ATOM_OP__AND       5
#define    GK110SASS_ATOM_OP__OR        6
#define    GK110SASS_ATOM_OP__XOR       7
#define    GK110SASS_ATOM_OP__EXCH      8
#define    GK110SASS_ATOM_OP__CAS       9
#define    GK110SASS_ATOM_OP__SAFEADD  10

#define GK110SASS_ATOM_SIZERA 54:52 // atomic operation size
#define    GK110SASS_ATOM_SIZERA__U32  0
#define    GK110SASS_ATOM_SIZERA__S32  1
#define    GK110SASS_ATOM_SIZERA__U64  2
#define    GK110SASS_ATOM_SIZERA__F32  3
#define    GK110SASS_ATOM_SIZERA__U128 4

#define GK110SASS_ATOM_IMM20 50:31
#define GK110SASS_ATOM_X     51:51

#define GK110SASS_MEMBAR_LVL    11:10
#define     GK110SASS_MEMBAR_LVL__CTA   0
#define     GK110SASS_MEMBAR_LVL__GL    1
#define     GK110SASS_MEMBAR_LVL__SYS   2

#define GK110SASS_BPT_IMM20     42:23

#define GK110SASS_BPT_MODE      10:8
#define     GK110SASS_BPT_MODE__RESERVED    0
#define     GK110SASS_BPT_MODE__CAL         1
#define     GK110SASS_BPT_MODE__PAUSE       2
#define     GK110SASS_BPT_MODE__TRAP        3
#define     GK110SASS_BPT_MODE__INT         4
#define     GK110SASS_BPT_MODE__DRAIN       5

#define GK110SASS_MOV_QUADMASK 45:42

#define GK110SASS_TEX_TSPTRIDXU13 59:47
#define GK110SASS_TLD_TSPTRIDXU13 57:45
// This is the same for TLD and TEX
#define GK110SASS_TEX_PARAMA 40:38
#define    GK110SASS_TEX_PARAMA__1D         0
#define    GK110SASS_TEX_PARAMA__1DARRAY    1
#define    GK110SASS_TEX_PARAMA__2D         2
#define    GK110SASS_TEX_PARAMA__2DARRAY    3
#define    GK110SASS_TEX_PARAMA__3D         4
#define    GK110SASS_TEX_PARAMA__3DARRAY    5
#define    GK110SASS_TEX_PARAMA__CUBE       6
#define    GK110SASS_TEX_PARAMA__CUBEARRAY  7

#define GK110SASS_SREG 30:23 // special purpose register

// These fields apply to 5 bit ST/LD instructions (INST5)
#define GK110SASS_INST5_SIZE3 58:56
#define    GK110SASS_INST5_SIZE3__U8   0
#define    GK110SASS_INST5_SIZE3__S8   1
#define    GK110SASS_INST5_SIZE3__U16  2
#define    GK110SASS_INST5_SIZE3__S16  3
#define    GK110SASS_INST5_SIZE3__32   4
#define    GK110SASS_INST5_SIZE3__64   5
#define    GK110SASS_INST5_SIZE3__128  6
#define    GK110SASS_INST5_SIZE3__U128 7

//Location of .E bit for ST/LD instructions
#define GK110SASS_LDST_X    55:55

#define GK110SASS_INST5_COP2  60:59
#define    GK110SASS_INST5_COP2__CA      0  // cache at all levels
#define    GK110SASS_INST5_COP2__CG      1  // cache at global level (see errata)
#define    GK110SASS_INST5_COP2__CS      2  // cache streaming
#define    GK110SASS_INST5_COP2__LU      2  // last use, same encoding as CS
#define    GK110SASS_INST5_COP2__CV      3  // cache as volatile



// These fields applied to most of the instructions
#define GK110SASS_PRED       21:18
#define    GK110SASS_PRED__UNCOND   7 // 7 is always true
#define GK110SASS_SYNC       22:22
#define GK110SASS_TRIG       15:15
#define GK110SASS_REGDEST     9: 2
#define GK110SASS_CCC         6: 2
#define    GK110SASS_CCC__CC_F      0x00
#define    GK110SASS_CCC__CC_LT     0x01
#define    GK110SASS_CCC__CC_EQ     0x02
#define    GK110SASS_CCC__CC_LE     0x03
#define    GK110SASS_CCC__CC_GT     0x04
#define    GK110SASS_CCC__CC_NE     0x05
#define    GK110SASS_CCC__CC_GE     0x06
#define    GK110SASS_CCC__CC_NUM    0x07
#define    GK110SASS_CCC__CC_NAN    0x08
#define    GK110SASS_CCC__CC_LTU    0x09
#define    GK110SASS_CCC__CC_EQU    0x0a
#define    GK110SASS_CCC__CC_LEU    0x0b
#define    GK110SASS_CCC__CC_GTU    0x0c
#define    GK110SASS_CCC__CC_NEU    0x0d
#define    GK110SASS_CCC__CC_GEU    0x0e
#define    GK110SASS_CCC__CC_T      0x0f
#define    GK110SASS_CCC__CC_OFF    0x10
#define    GK110SASS_CCC__CC_LO     0x11
#define    GK110SASS_CCC__CC_SFF    0x12
#define    GK110SASS_CCC__CC_LS     0x13
#define    GK110SASS_CCC__CC_HI     0x14
#define    GK110SASS_CCC__CC_SFT    0x15
#define    GK110SASS_CCC__CC_HS     0x16
#define    GK110SASS_CCC__CC_OFT    0x17
// 0x18-0x1D are non-compute CCs
#define    GK110SASS_CCC__CC_RLE    0x1e
#define    GK110SASS_CCC__CC_RGT    0x1f

#define GK110SASS_CCC_ALT     14: 10
#define    GK110SASS_CCC_ALT__CC_T  0x0f

#define GK110SASS_ICA         7: 7
#define GK110SASS_LMT         8: 8
#define GK110SASS_INC         8: 8
#define GK110SASS_U           9: 9
#define GK110SASS_REGA       17:10
#define GK110SASS_REGB       30:23
#define GK110SASS_REGC       49:42

#define GK110SASS_IADD_X        46:46
#define GK110SASS_IADD_WRITECC  50:50

#define GK110SASS_32I_X         56:56
#define GK110SASS_32I_WRITECC   55:55

#define GK110SASS_IMM30        54:25
#define GK110SASS_IMM32        54:23
#define GK110SASS_IMM24        46:23

#define GK110SASS_IMM20(imm20) BF_FLDV(59:59, imm20 >> 19) + BF_FLDV(41:23, imm20)
#define GK110SASS_PSIGN     52:51
#define     GK110SASS_PSIGN__NONE  0
#define     GK110SASS_PSIGN__NEGB  1
#define     GK110SASS_PSIGN__NEGA  2
#define GK110SASS_32I_PSIGN 59:58
#define     GK110SASS_32I_PSIGN__NONE   0
#define     GK110SASS_32I_PSIGN__NEGB   #error "NEGB is illegal on IADD32I"
#define     GK110SASS_32I_PSIGN__NEGA   2


#define GK110SASS_SIZE3     53:51
#define    GK110SASS_SIZE3__U8     0
#define    GK110SASS_SIZE3__S8     1
#define    GK110SASS_SIZE3__U16    2
#define    GK110SASS_SIZE3__S16    3
#define    GK110SASS_SIZE3__32     4
#define    GK110SASS_SIZE3__64     5
#define    GK110SASS_SIZE3__128    6
#define    GK110SASS_SIZE3__U128   7

// COP1 as in the MD file; used by SULDGA currently
#define GK110SASS_COP1      55:54
#define    GK110SASS_COP1__CA      0  // cache at all levels
#define    GK110SASS_COP1__CG      1  // cache at global level (see errata)
#define    GK110SASS_COP1__CS      2  // cache streaming
#define    GK110SASS_COP1__LU      2  // last use, same encoding as CS
#define    GK110SASS_COP1__CV      3  // cache as volatile

// COP2 as in the MD file
#define GK110SASS_COP2      48:47
#define    GK110SASS_COP2__CA      0  // cache at all levels
#define    GK110SASS_COP2__CG      1  // cache at global level (see errata)
#define    GK110SASS_COP2__CS      2  // cache streaming
#define    GK110SASS_COP2__LU      2  // last use, same encoding as CS
#define    GK110SASS_COP2__CV      3  // cache as volatile

// COP3 as in the MD file; used by SULDGAI currently
#define GK110SASS_COP3      32:31
#define    GK110SASS_COP3__CA      0  // cache at all levels
#define    GK110SASS_COP3__CG      1  // cache at global level (see errata)
#define    GK110SASS_COP3__CS      2  // cache streaming
#define    GK110SASS_COP3__LU      2  // last use, same encoding as CS
#define    GK110SASS_COP3__CV      3  // cache as volatile

#define GK110SASS_COP4      5:2
#define    GK110SASS_COP4__QRY1    0
#define    GK110SASS_COP4__PF1     1
#define    GK110SASS_COP4__PF15    2
#define    GK110SASS_COP4__PF2     3
#define    GK110SASS_COP4__WB      4
#define    GK110SASS_COP4__IV      5
#define    GK110SASS_COP4__IVALL   6
#define    GK110SASS_COP4__RS      7
#define    GK110SASS_COP4__RSLB    8

#define GK110SASS_CACHE3    8:6
#define    GK110SASS_CACHE3__D     0
#define    GK110SASS_CACHE3__U     1
#define    GK110SASS_CACHE3__C     2
#define    GK110SASS_CACHE3__I     3
#define    GK110SASS_CACHE3__CRS   4

#define GK110SASS_ICOMP3    54:52
#define    GK110SASS_ICOMP3__F     0
#define    GK110SASS_ICOMP3__LT    1
#define    GK110SASS_ICOMP3__EQ    2
#define    GK110SASS_ICOMP3__LE    3
#define    GK110SASS_ICOMP3__GT    4
#define    GK110SASS_ICOMP3__NE    5
#define    GK110SASS_ICOMP3__GE    6
#define    GK110SASS_ICOMP3__T     7

// These fields apply to VOTE instruction
#define GK110SASS_VOP       52:51
#define GK110SASS_VOP__ALL  0
#define GK110SASS_VOP__ANY  1
#define GK110SASS_VOP__EQ   2

#define GK110SASS_PREDSRC 45:42

#define GK110SASS_QUAD      17:14

#define GK110SASS_TEX_REGD       9:2
#define GK110SASS_TEX_WRITEMASK 37:34
#define GK110SASS_TEX_PTRIDX    57:45
#define GK110SASS_TEX_REGB      30:23
#define GK110SASS_TEX_DIM       40:39

// These fields apply to ISETP instruction
#define GK110SASS_ISETP_FMT        51:51
#define GK110SASS_ISETP_FMT__U32   0
#define GK110SASS_ISETP_FMT__S32   1

// Shint fields
// This is generated using the macro as :
// ((inst)*8 + 9 : (inst)*8 + 2), where inst = [0,6] is the offset of the
// instruction in the cache line _AFTER_ the shint itself
#define GK110SASS_SHINT_TARGETS     57:2
#define GK110SASS_SHINT_TARGETS_INST_0  9:2
#define GK110SASS_SHINT_TARGETS_INST_1  17:10
#define GK110SASS_SHINT_TARGETS_INST_2  25:18
#define GK110SASS_SHINT_TARGETS_INST_3  33:26
#define GK110SASS_SHINT_TARGETS_INST_4  41:34
#define GK110SASS_SHINT_TARGETS_INST_5  49:42
#define GK110SASS_SHINT_TARGETS_INST_6  57:50

#define GK110SASS_SHINT_TYPES   7:0
#define GK110SASS_SHINT_TYPES_WAIT_FIELD               4:0
#define GK110SASS_SHINT_TYPES_YIELD_YYY                6:4
#define GK110SASS_SHINT_TYPES_YIELD_WWW                3:0

#define GK110SASS_SHINT_TYPES__HW_DEFAULT               0x00
#define GK110SASS_SHINT_TYPES__PAIR                     0x04
#define GK110SASS_SHINT_TYPES__HOLD_IFB                 0x05
#define GK110SASS_SHINT_TYPES__HOLD_ALL                 0x06
#define GK110SASS_SHINT_TYPES__HOLD_IFB_REORDER         0x07
#define GK110SASS_SHINT_TYPES__HOLD_IFB_FULL_REORDER    0x10
#define GK110SASS_SHINT_TYPES__WAIT1_FULL_REORDER       0x11
#define GK110SASS_SHINT_TYPES__WAIT4_FULL_REORDER       0x12
#define GK110SASS_SHINT_TYPES__HOLD_IFB_MULTI_FULL_REORDER 0x13
#define GK110SASS_SHINT_TYPES__WAIT                     0x20
#define GK110SASS_SHINT_TYPES__WAIT_REORDER             0x40
#define GK110SASS_SHINT_TYPES__WAIT_MULTI               0x60
#define GK110SASS_SHINT_TYPES__WAIT_BOOST               0xe0
#define GK110SASS_SHINT_TYPES__WAIT_YIELD               0x80

#define GK110SASS_WAIT(time) (BF_FLDV(GK110SASS_SHINT_TYPES_WAIT_FIELD, time))
#define GK110SASS_SHINT_TARGETS_INST(inst) (9 +(inst)*8):(2 + (inst)*8)

#define GK110SASS_SET_SHINT(base, inst, type)                     \
    (BF_SETFLDV(base, GK110SASS_SHINT_TARGETS_INST(inst),         \
                GK110SASS_SHINT_TYPES__##type))

#define GK110SASS_SET_SHINT_WAIT(base, inst, type, time)           \
        (BF_SETFLDV(base, GK110SASS_SHINT_TARGETS_INST(inst),     \
         GK110SASS_SHINT_TYPES__##type + GK110SASS_WAIT(time)))

// Note, these macro depends on BF_FLDV masking off stuff outside the field
#define GK110SASS_INST3(opcode3) (BF_FLDV(63:63, opcode3) + BF_FLDV(1:0, opcode3 >> 1))
#define GK110SASS_INST4(opcode4) (BF_FLDV(63:62, opcode4) + BF_FLDV(1:0, opcode4 >> 2))
#define GK110SASS_INST5(opcode5) (BF_FLDV(63:61, opcode5) + BF_FLDV(1:0, opcode5 >> 3))
#define GK110SASS_INST6(opcode6) (BF_FLDV(63:60, opcode6) + BF_FLDV(1:0, opcode6 >> 4))
#define GK110SASS_INST7(opcode7) (BF_FLDV(63:59, opcode7) + BF_FLDV(1:0, opcode7 >> 5))

#define GK110SASS_INST3_MASK     (BF_FLDV(63:63, ~0ULL) + BF_FLDV(1:0, ~0ULL))
#define GK110SASS_INST4_MASK     (BF_FLDV(63:62, ~0ULL) + BF_FLDV(1:0, ~0ULL))
#define GK110SASS_INST5_MASK     (BF_FLDV(63:61, ~0ULL) + BF_FLDV(1:0, ~0ULL))
#define GK110SASS_INST6_MASK     (BF_FLDV(63:60, ~0ULL) + BF_FLDV(1:0, ~0ULL))
#define GK110SASS_INST7_MASK     (BF_FLDV(63:59, ~0ULL) + BF_FLDV(1:0, ~0ULL))

#define GK110SASS_INST3_3_4(opcode3fld,subopcode3_4)                                                     \
    (GK110SASS_INST3(GK110SASS_OPCODE3__##opcode3fld) +                                                  \
     BF_FLDV(GK110SASS_OPCODE3SUB3SUB4_HI,GK110SASS_OPCODE3SUB3SUB4__##subopcode3_4 >> 4) +              \
     BF_FLDV(GK110SASS_OPCODE3SUB3SUB4_LO,GK110SASS_OPCODE3SUB3SUB4__##subopcode3_4))

#define GK110SASS_INST3_3_5(opcode3fld,subopcode3_5)                                                     \
    (GK110SASS_INST3(GK110SASS_OPCODE3__##opcode3fld) +                                                  \
     BF_FLDV(GK110SASS_OPCODE3SUB3SUB5_HI,GK110SASS_OPCODE3SUB3SUB5__##subopcode3_5 >> 5) +              \
     BF_FLDV(GK110SASS_OPCODE3SUB3SUB5_LO,GK110SASS_OPCODE3SUB3SUB5__##subopcode3_5))

#define GK110SASS_INST4_7(opcode4fld,subopcode7)                            \
    (GK110SASS_INST4(GK110SASS_OPCODE4__##opcode4fld) +                     \
     BF_FLD(GK110SASS_OPCODE4SUB7,subopcode7))

#define GK110SASS_INST4_8(opcode4fld,subopcode8)                            \
    (GK110SASS_INST4(GK110SASS_OPCODE4__##opcode4fld) +                     \
     BF_FLD(GK110SASS_OPCODE4SUB8,subopcode8))

#define GK110SASS_INST5_2(opcode5fld,subopcode2)                            \
    (GK110SASS_INST5(GK110SASS_OPCODE5__##opcode5fld) +                     \
     BF_FLD(GK110SASS_OPCODE5SUB2,subopcode2))

#define GK110SASS_INST5_6(opcode5fld,subopcode6)                            \
    (GK110SASS_INST5(GK110SASS_OPCODE5__##opcode5fld) +                     \
     BF_FLD(GK110SASS_OPCODE5SUB6,subopcode6))

#define GK110SASS_INST5_6_MASK                                              \
    (GK110SASS_INST5_MASK +                                                 \
     BF_FLDV(GK110SASS_OPCODE5SUB6, ~0ULL))

#define GK110SASS_INST7_1(opcode7fld,subopcode1)                            \
    (GK110SASS_INST7(GK110SASS_OPCODE7__##opcode7fld) +                     \
     BF_FLD(GK110SASS_OPCODE7SUB1,subopcode1))

#define GK110SASS_INST7_3(opcode7fld,subopcode3)                            \
    (GK110SASS_INST7(GK110SASS_OPCODE7__##opcode7fld) +                     \
     BF_FLD(GK110SASS_OPCODE7SUB3,subopcode3))

#define GK110SASS_INST7_4(opcode7fld,subopcode4)                            \
    (GK110SASS_INST7(GK110SASS_OPCODE7__##opcode7fld) +                     \
     BF_FLD(GK110SASS_OPCODE7SUB4,subopcode4))

#define GK110SASS_INST7_5(opcode7fld,subopcode5)                            \
    (GK110SASS_INST7(GK110SASS_OPCODE7__##opcode7fld) +                     \
     BF_FLD(GK110SASS_OPCODE7SUB5,subopcode5))

#define GK110SASS_INST7_5_MASK                                              \
    (GK110SASS_INST7_MASK +                                                 \
     BF_FLDV(GK110SASS_OPCODE7SUB5, ~0ULL))

#define GK110SASS_INST_ISETPI(fmt, cc, pd, ra, imm20)                       \
    (GK110SASS_INST3_3_4(B20I, ISETP) +                                     \
     GK110SASS_IMM20(imm20) +                                               \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(4:2,7) +                                                       \
     BF_FLDV(7:5,pd) +                                                      \
     BF_FLDV(GK110SASS_PREDSRC,PT) +                                        \
     BF_FLD(GK110SASS_ICOMP3,cc) +                                          \
     BF_FLD(GK110SASS_ISETP_FMT, fmt))

#define GK110SASS_INST_IADDI(rd, ra, imm20)                                 \
    (GK110SASS_INST3_3_5(B20I, IADD) +                                      \
     GK110SASS_IMM20(imm20) +                                               \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))                                         \
 
#define GK110SASS_INST_SHL(rd, ra, rb)                                      \
    (GK110SASS_INST4_8(MISC3, SHL) +                                        \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_SHRI(rd, ra, imm20)                                  \
    (GK110SASS_INST3_3_5(B20I, SHR) +                                       \
     GK110SASS_IMM20(imm20) +                                               \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_BFEI(rd, ra, imm20)                                  \
    (GK110SASS_INST3_3_5(B20I, BFE) +                                       \
     GK110SASS_IMM20(imm20) +                                               \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_BFII(rd, ra, rc, imm20)                              \
    (GK110SASS_INST3_3_5(B20I, BFI) +                                       \
     GK110SASS_IMM20(imm20) +                                               \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGC,rc) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_LOPI(lop, rd, ra, imm20)                             \
    (GK110SASS_INST3_3_5(B20I, LOP) +                                       \
     GK110SASS_IMM20(imm20) +                                               \
     BF_FLD(GK110SASS_LOP, lop) +                                           \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_ISETP(cc, pd, ra, rb)                                \
    (GK110SASS_INST4_7(MISC3, ISETP) +                                      \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(4:2,7) +                                                       \
     BF_FLDV(7:5,pd) +                                                      \
     BF_FLDV(GK110SASS_PREDSRC,PT) +                                        \
     BF_FLD(GK110SASS_ICOMP3,cc))

#define GK110SASS_INST_ISET(cc, rd, ra, rb)                                 \
    (GK110SASS_INST4_7(MISC3, ISET) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(GK110SASS_TEX_REGD,rd) +                                       \
     BF_FLDV(GK110SASS_PREDSRC,PT) +                                        \
     BF_FLD(GK110SASS_ICOMP3,cc))

#define GK110SASS_INST_ICMP(cc, rd, ra, rb, sc)                             \
    (GK110SASS_INST4_7(MISC3, ICMP) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(GK110SASS_TEX_REGD,rd) +                                       \
     BF_FLDV(GK110SASS_REGC, sc) +                                          \
     BF_FLD(GK110SASS_ICOMP3,cc))

#define GK110SASS_INST_ISETPI_FULL(cc, bop, x, pd, ra, imm20, ps)            \
    (GK110SASS_INST3_3_4(B20I, ISETP) +                                     \
     GK110SASS_IMM20(imm20) +                                               \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLD(GK110SASS_BOP1,bop) +                                           \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(46:46,x) +                                                     \
     BF_FLDV(4:2,7) +                                                       \
     BF_FLDV(7:5,pd) +                                                      \
     BF_FLDV(GK110SASS_PREDSRC,ps) +                                        \
     BF_FLD(GK110SASS_ICOMP3,cc))

#define GK110SASS_INST_ISETP_FULL(cc, bop, x, pd, ra, rb, ps)               \
    (GK110SASS_INST4_7(MISC3, ISETP) +                                      \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLD(GK110SASS_BOP1,bop) +                                           \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(46:46,x) +                                                     \
     BF_FLDV(4:2,7) +                                                       \
     BF_FLDV(7:5,pd) +                                                      \
     BF_FLDV(GK110SASS_PREDSRC,ps) +                                        \
     BF_FLD(GK110SASS_ICOMP3,cc))

#define GK110SASS_INST_ISETP_S32_FULL(cc, bop, x, pd, pu, ra, rb, ps)       \
    (GK110SASS_INST4_7(MISC3, ISETP) +                                      \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLD(GK110SASS_BOP1,bop) +                                           \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(46:46,x) +                                                     \
     BF_FLDV(51:51,1) +                                                     \
     BF_FLDV(4:2,pu) +                                                      \
     BF_FLDV(7:5,pd) +                                                      \
     BF_FLDV(GK110SASS_PREDSRC,ps) +                                        \
     BF_FLD(GK110SASS_ICOMP3,cc))

#define GK110SASS_INST_ISETP_FULL_FMT(cc, fmt, bop, x, pd, ra, rb, ps)      \
    (GK110SASS_INST4_7(MISC3, ISETP) +                                      \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(51:51,fmt) +                                                   \
     BF_FLD(GK110SASS_BOP1,bop) +                                           \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(46:46,x) +                                                     \
     BF_FLDV(4:2,7) +                                                       \
     BF_FLDV(7:5,pd) +                                                      \
     BF_FLDV(GK110SASS_PREDSRC,ps) +                                        \
     BF_FLD(GK110SASS_ICOMP3,cc))

#define GK110SASS_INST_IADD_FULL(x, psign, cc, rd, ra, rb)                  \
    (GK110SASS_INST4_8(MISC3, IADD) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd) +                                        \
     BF_FLDV(GK110SASS_IADD_X,x) +                                          \
     BF_FLDV(GK110SASS_IADD_WRITECC,cc) +                                   \
     BF_FLD(GK110SASS_PSIGN, psign))

#define GK110SASS_INST_IADD(rd, ra, rb)         GK110SASS_INST_IADD_FULL(0, NONE, 0, rd, ra, rb)
#define GK110SASS_INST_IADD_CC(rd, ra, rb)      GK110SASS_INST_IADD_FULL(0, NONE, 1, rd, ra, rb)
#define GK110SASS_INST_IADD_X(rd, ra, rb)       GK110SASS_INST_IADD_FULL(1, NONE  0, rd, ra, rb)
#define GK110SASS_INST_IADD_NEGB(rd, ra, rb)    GK110SASS_INST_IADD_FULL(0, NEGB, 0, rd, ra, rb)
#define GK110SASS_INST_IADD_NEGB_CC(rd, ra, rb) GK110SASS_INST_IADD_FULL(0, NEGB, 1, rd, ra, rb)
#define GK110SASS_INST_IADD_NEGB_X(rd, ra, rb)  GK110SASS_INST_IADD_FULL(1, NEGB, 0, rd, ra, rb)

#define GK110SASS_INST_FLO(rd, rb)                                          \
    (GK110SASS_INST4_8(MISC3, FLO) +                                        \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_MOV(rd, rs)                                          \
    (GK110SASS_INST4_8(MISC3, MOV) +                                        \
     BF_FLDV(GK110SASS_MOV_QUADMASK,0xf) +                                  \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGB,rs) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_LOP(lop, rd, ra, rb)                                 \
    (GK110SASS_INST4_8(MISC3, LOP) +                                        \
     BF_FLD(GK110SASS_LOP, lop) +                                           \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_LOP_CC(lop, rd, ra, rb)                              \
    (GK110SASS_INST4_8(MISC3, LOP) +                                        \
     BF_FLD(GK110SASS_LOP, lop) +                                           \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLDV(50:50,1) +                                                     \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_LOP_NOTSB(lop, rd, ra, rb)                           \
    (GK110SASS_INST4_8(MISC3, LOP) +                                        \
     BF_FLD(GK110SASS_LOP, lop) +                                           \
     BF_FLDV(43:43,1) +                                                     \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_IMUL(rd, ra, rb)                                     \
    (GK110SASS_INST4_8(MISC3, IMUL) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,rb) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_P2R(rd)                                              \
    (GK110SASS_INST3_3_5(B20I, P2R) +                                       \
     GK110SASS_IMM20(0xffff) +                                              \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,RZ) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_R2P(ra)                                              \
    (GK110SASS_INST3_3_5(B20I, R2P) +                                       \
     GK110SASS_IMM20(0xffff) +                                              \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra))

#define GK110SASS_INST_R2P_SB(ra, sbmask)                                   \
    (GK110SASS_INST3_3_5(B20I, R2P) +                                       \
     GK110SASS_IMM20(sbmask) +                                              \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra))

#define GK110SASS_INST_S2R(rd, sr)                                          \
    (GK110SASS_INST7_5(MISC2, OP_S2R) +                                     \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_SREG,sr) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_S2R_MASK GK110SASS_INST7_5_MASK

#define GK110SASS_INST_PSETP(cc, pu, pp, pq)                                \
    (GK110SASS_INST7_5(MISC2, PSETP) +                                      \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLD(GK110SASS_BOP1,AND) +                                           \
     BF_FLDV(GK110SASS_PREDSRC,PT) +                                        \
     BF_FLDV(35:32,pq) +                                                    \
     BF_FLD(GK110SASS_BOP0,cc) +                                            \
     BF_FLDV(17:14,pp) +                                                    \
     BF_FLDV(7:5, pu) +                                                     \
     BF_FLDV(4:2, PT))

#define GK110SASS_INST_CSETP(pu, test)                                      \
    (GK110SASS_INST7_5(MISC2, CSETP) +                                      \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLD(GK110SASS_BOP0,AND) +                                           \
     BF_FLDV(44:42, PT) +                                                    \
     BF_FLDV(14:10, test) +                                                 \
     BF_FLDV(7:5, pu) +                                                     \
     BF_FLDV(4:2, PT))

#define GK110SASS_INST_BAR(barsrcmode, barmode, barcount, barname, red)     \
    (GK110SASS_INST7_5(MISC2, BAR) +                                        \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLD(GK110SASS_BARSRCMODE, barsrcmode) +                             \
     BF_FLDV(GK110SASS_PREDSRC,PT) +                                        \
     BF_FLD(GK110SASS_BARMODE, barmode) +                                   \
     BF_FLDV(34:23,barcount) +                                              \
     BF_FLDV(17:10,barname) +                                               \
     BF_FLD(GK110SASS_BARREDOP, red))

#define GK110SASS_INST_B2R(type, rd, barname)                               \
     (GK110SASS_INST7_5(MISC2, B2R) +                                       \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLD(GK110SASS_B2RTYPE, type) +                                      \
     BF_FLDV(GK110SASS_B2RNAME, barname) +                                  \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_NOP(sync)                                            \
    (GK110SASS_INST7_5(MISC2, NO_OP) +                                      \
     BF_FLDV(GK110SASS_SYNC,sync) +                                         \
     BF_FLD(GK110SASS_CCC_ALT,CC_T) +                                       \
     BF_FLD(GK110SASS_PRED,UNCOND))

#define GK110SASS_INST_NOP_TRIG(sync,trig)                                  \
    (GK110SASS_INST7_5(MISC2, NO_OP) +                                      \
     BF_FLDV(GK110SASS_SYNC, sync) +                                        \
     BF_FLDV(GK110SASS_TRIG, trig))

#define GK110SASS_INST_NOP_MASK                                             \
    (GK110SASS_INST7_5_MASK +                                               \
     BF_FLDV(GK110SASS_SYNC, ~0ULL) +                                       \
     BF_FLDV(GK110SASS_TRIG, ~0ULL))

#define GK110SASS_INST_LONGJMP                                              \
    (GK110SASS_INST5_6(CTRL, LONGJMP) +                                     \
     BF_FLD(GK110SASS_CCC,CC_T) +                                           \
     BF_FLD(GK110SASS_PRED,UNCOND))

#define GK110SASS_INST_VOTE(op, rd, pu, pp)                                 \
    (GK110SASS_INST7_5(MISC2, VOTE) +                                       \
     BF_FLD(GK110SASS_VOP, op) +                                            \
     BF_FLDV(GK110SASS_PREDSRC, pp) +                                       \
     BF_FLDV(50:48, pu) +                                                   \
     BF_FLD(GK110SASS_PRED, UNCOND) +                                       \
     BF_FLDV(GK110SASS_REGDEST, rd))

#define GK110SASS_INST_BRA(target)                                          \
    (GK110SASS_INST5_6(CTRL, BRA) +                                         \
     BF_FLDV(GK110SASS_ICA,0) +                                             \
     BF_FLD(GK110SASS_CCC,CC_T) +                                           \
     BF_FLDV(GK110SASS_IMM24, target) +                                     \
     BF_FLD(GK110SASS_PRED,UNCOND))

#define GK110SASS_INST_JMP_ABS(target)                                      \
    (GK110SASS_INST5_6(CTRL, JMP) +                                         \
     BF_FLDV(GK110SASS_ICA,0) +                                             \
     BF_FLD(GK110SASS_CCC,CC_T) +                                           \
     BF_FLDV(GK110SASS_IMM32, target) +                                     \
     BF_FLD(GK110SASS_PRED,UNCOND))

#define GK110SASS_INST_JMP_ABS_C(b, k)                                      \
    (GK110SASS_INST5_6(CTRL, JMP) +                                         \
     BF_FLDV(GK110SASS_ICA,1) +                                             \
     BF_FLD(GK110SASS_CCC,CC_T) +                                           \
     BF_FLDV(GK110SASS_JMP_CBANK5,b) +                                      \
     BF_FLDV(GK110SASS_JMP_CA16,k) +                                        \
     BF_FLD(GK110SASS_PRED,UNCOND))

#define GK110SASS_INST_JCAL(target)                                         \
    (GK110SASS_INST5_6(CTRL, JCAL) +                                        \
     BF_FLDV(GK110SASS_ICA,0) +                                             \
     BF_FLDV(GK110SASS_INC,1) +                                             \
     BF_FLDV(GK110SASS_IMM32, target))

#define GK110SASS_INST_JCAL_NOINC(target)                                   \
    (GK110SASS_INST5_6(CTRL, JCAL) +                                        \
     BF_FLDV(GK110SASS_ICA,0) +                                             \
     BF_FLDV(GK110SASS_INC,0) +                                             \
     BF_FLDV(GK110SASS_IMM32, target))

#define GK110SASS_INST_SSY(target)                                          \
    (GK110SASS_INST5_6(CTRL, SSY) +                                         \
     BF_FLDV(GK110SASS_ICA,0) +                                             \
     BF_FLD(GK110SASS_CCC,CC_T) +                                           \
     BF_FLDV(GK110SASS_IMM24, target) +                                     \
     BF_FLD(GK110SASS_PRED,UNCOND))

#define GK110SASS_INST_PRET(target,inc)                                     \
    (GK110SASS_INST5_6(CTRL, PRET) +                                        \
     BF_FLDV(GK110SASS_ICA,0) +                                             \
     BF_FLDV(GK110SASS_INC,inc) +                                           \
     BF_FLD(GK110SASS_CCC,CC_T) +                                           \
     BF_FLDV(GK110SASS_IMM24, target) +                                     \
     BF_FLD(GK110SASS_PRED,UNCOND))

#define GK110SASS_INST_PLONGJMP(target)                                     \
    (GK110SASS_INST5_6(CTRL, PLONGJMP) +                                    \
     BF_FLDV(GK110SASS_ICA,0) +                                             \
     BF_FLD(GK110SASS_CCC,CC_T) +                                           \
     BF_FLDV(GK110SASS_IMM24, target) +                                     \
     BF_FLD(GK110SASS_PRED,UNCOND))

#define GK110SASS_INST_RET                                                  \
    (GK110SASS_INST5_6(CTRL, RET) +                                         \
     BF_FLD(GK110SASS_CCC,CC_T) +                                           \
     BF_FLD(GK110SASS_PRED,UNCOND))

#define GK110SASS_INST_EXIT                                                 \
    (GK110SASS_INST5_6(CTRL, OP_EXIT) +                                     \
     BF_FLD(GK110SASS_CCC,CC_T) +                                           \
     BF_FLD(GK110SASS_PRED,UNCOND))

#define GK110SASS_INST_EXIT_MASK (GK110SASS_INST5_6_MASK)
#define GK110SASS_INST_RET_MASK (GK110SASS_INST5_6_MASK)

#define GK110SASS_INST_LD_MASK (GK110SASS_INST5_MASK)

#define GK110SASS_INST_LD_OPCODE (GK110SASS_INST5(GK110SASS_OPCODE5__LD))

#define GK110SASS_INST_LD_FULL(extended, cop, size, rd, ra, addr)       \
    (GK110SASS_INST_LD_OPCODE +                                         \
     BF_FLD(GK110SASS_INST5_SIZE3,size) +                               \
     BF_FLD(GK110SASS_INST5_COP2,cop) +                                 \
     BF_FLDV(GK110SASS_IMM32, addr) +                                   \
     BF_FLDV(GK110SASS_SYNC,0) +                                        \
     BF_FLDV(GK110SASS_LDST_X,extended) +                               \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                    \
     BF_FLDV(GK110SASS_REGA,ra) +                                       \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_LD(rd, ra, addr)       GK110SASS_INST_LD_FULL(0, CA,  32, rd, ra, addr)
#define GK110SASS_INST_LD32_X(rd, ra, addr)   GK110SASS_INST_LD_FULL(1, CA,  32, rd, ra, addr)
#define GK110SASS_INST_LD64(rd, ra, addr)     GK110SASS_INST_LD_FULL(0, CA,  64, rd, ra, addr)
#define GK110SASS_INST_LD64_X(rd, ra, addr)   GK110SASS_INST_LD_FULL(1, CA,  64, rd, ra, addr)
#define GK110SASS_INST_LD128(rd, ra, addr)    GK110SASS_INST_LD_FULL(0, CA, 128, rd, ra, addr)

#define GK110SASS_INST_LD_CG(rd, ra, addr)     GK110SASS_INST_LD_FULL(0, CG,  32, rd, ra, addr)
#define GK110SASS_INST_LD32_X_CG(rd, ra, addr) GK110SASS_INST_LD_FULL(1, CG,  32, rd, ra, addr)
#define GK110SASS_INST_LD64_CG(rd, ra, addr)   GK110SASS_INST_LD_FULL(0, CG,  64, rd, ra, addr)
#define GK110SASS_INST_LD64_X_CG(rd, ra, addr) GK110SASS_INST_LD_FULL(1, CG,  64, rd, ra, addr)
#define GK110SASS_INST_LD128_CG(rd, ra, addr)  GK110SASS_INST_LD_FULL(0, CG, 128, rd, ra, addr)

#define GK110SASS_INST_LDC(rd, b, addr)                                     \
    (GK110SASS_INST7_5(MISC1, LDC) +                                        \
     BF_FLD(GK110SASS_SIZE3,32) +                                           \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,RZ) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd) +                                        \
     BF_FLDV(GK110SASS_LDC_CBANK5,b) +                                      \
     BF_FLDV(GK110SASS_LDC_CA16,addr))

#define GK110SASS_INST_LDL16(rd, ra, addr)                                  \
    (GK110SASS_INST7_5(MISC1, OP_LDL) +                                     \
     BF_FLD(GK110SASS_SIZE3,U16) +                                          \
     BF_FLD(GK110SASS_COP2,CA) +                                            \
     BF_FLDV(GK110SASS_IMM24, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))


#define GK110SASS_INST_LDL(rd, ra, addr)                                    \
    (GK110SASS_INST7_5(MISC1, OP_LDL) +                                     \
     BF_FLD(GK110SASS_SIZE3,32) +                                           \
     BF_FLD(GK110SASS_COP2,CA) +                                            \
     BF_FLDV(GK110SASS_IMM24, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_LDL128(rd, ra, addr)                                 \
    (GK110SASS_INST7_5(MISC1, OP_LDL) +                                     \
     BF_FLD(GK110SASS_SIZE3,128) +                                          \
     BF_FLD(GK110SASS_COP2,CA) +                                            \
     BF_FLDV(GK110SASS_IMM24, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_LDS(rd, ra, addr)                                    \
    (GK110SASS_INST7_5(MISC1, LDS) +                                        \
     BF_FLD(GK110SASS_SIZE3,32) +                                           \
     BF_FLD(GK110SASS_COP2,CA) +                                            \
     BF_FLDV(GK110SASS_IMM24, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_LDS128(rd, ra, addr)                                 \
    (GK110SASS_INST7_5(MISC1, LDS) +                                        \
     BF_FLD(GK110SASS_SIZE3,128) +                                          \
     BF_FLD(GK110SASS_COP2,CA) +                                            \
     BF_FLDV(GK110SASS_IMM24, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_ST(ra, addr, r)                                      \
    (GK110SASS_INST5(GK110SASS_OPCODE5__ST) +                               \
     BF_FLD(GK110SASS_INST5_SIZE3,32) +                                     \
     BF_FLD(GK110SASS_INST5_COP2,CA) +                                      \
     BF_FLDV(GK110SASS_IMM32, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,r))

#define GK110SASS_INST_ST32_X(ra, addr, r)                                  \
    (GK110SASS_INST5(GK110SASS_OPCODE5__ST) +                               \
     BF_FLD(GK110SASS_INST5_SIZE3,32) +                                     \
     BF_FLD(GK110SASS_INST5_COP2,CA) +                                      \
     BF_FLDV(GK110SASS_IMM32, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLDV(GK110SASS_LDST_X,1) +                                          \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,r))

#define GK110SASS_INST_ST64(ra, addr, r)                                    \
    (GK110SASS_INST5(GK110SASS_OPCODE5__ST) +                               \
     BF_FLD(GK110SASS_INST5_SIZE3,64) +                                     \
     BF_FLD(GK110SASS_INST5_COP2,CA) +                                      \
     BF_FLDV(GK110SASS_IMM32, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,r))

#define GK110SASS_INST_ST64_X(ra, addr, r)                                  \
    (GK110SASS_INST5(GK110SASS_OPCODE5__ST) +                               \
     BF_FLD(GK110SASS_INST5_SIZE3,64) +                                     \
     BF_FLD(GK110SASS_INST5_COP2,CA) +                                      \
     BF_FLDV(GK110SASS_IMM32, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLDV(GK110SASS_LDST_X,1) +                                          \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,r))

#define GK110SASS_INST_STL16(ra, addr, r)                                   \
    (GK110SASS_INST7_5(MISC1, STL) +                                        \
     BF_FLD(GK110SASS_SIZE3,U16) +                                          \
     BF_FLD(GK110SASS_COP2,CA) +                                            \
     BF_FLDV(GK110SASS_IMM24, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,r))

#define GK110SASS_INST_STL(ra, addr, r)                                     \
    (GK110SASS_INST7_5(MISC1, STL) +                                        \
     BF_FLD(GK110SASS_SIZE3,32) +                                           \
     BF_FLD(GK110SASS_COP2,CA) +                                            \
     BF_FLDV(GK110SASS_IMM24, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,r))

#define GK110SASS_INST_STL64(ra, addr, r)                                   \
    (GK110SASS_INST7_5(MISC1, STL) +                                        \
     BF_FLD(GK110SASS_SIZE3,64) +                                           \
     BF_FLD(GK110SASS_COP2,CA) +                                            \
     BF_FLDV(GK110SASS_IMM24, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,r))

#define GK110SASS_INST_STL128(ra, addr, r)                                  \
    (GK110SASS_INST7_5(MISC1, STL) +                                        \
     BF_FLD(GK110SASS_SIZE3,128) +                                          \
     BF_FLD(GK110SASS_COP2,CA) +                                            \
     BF_FLDV(GK110SASS_IMM24, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,r))

#define GK110SASS_INST_STS(ra, addr, r)                                     \
    (GK110SASS_INST7_5(MISC1, STS) +                                        \
     BF_FLD(GK110SASS_SIZE3,32) +                                           \
     BF_FLD(GK110SASS_COP2,CA) +                                            \
     BF_FLDV(GK110SASS_IMM24, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,r))

#define GK110SASS_INST_STS128(ra, addr, r)                                  \
    (GK110SASS_INST7_5(MISC1, STS) +                                        \
     BF_FLD(GK110SASS_SIZE3,128) +                                          \
     BF_FLD(GK110SASS_COP2,CA) +                                            \
     BF_FLDV(GK110SASS_IMM24, addr) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,r))

#define GK110SASS_INST_MOV32I(rd, imm32)                                    \
    (GK110SASS_INST7_4(MISC0, MOV32I) +                                     \
     BF_FLDV(GK110SASS_IMM32, imm32) +                                      \
     BF_FLDV(GK110SASS_QUAD, 0xf) +                                         \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_LOP32I(lop, rd, ra, imm32)                           \
    (GK110SASS_INST5(GK110SASS_OPCODE5__LOP32I) +                           \
     BF_FLDV(GK110SASS_IMM32, imm32) +                                      \
     BF_FLD(GK110SASS_LOP_32I, lop) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_IMUL32I(rd, ra, imm32)                               \
    (GK110SASS_INST7(GK110SASS_OPCODE7__IMUL32I) +                          \
     BF_FLDV(GK110SASS_IMM32, imm32) +                                      \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_IADD32I_FULL(x, psign, cc, rd, ra, imm32)            \
    (GK110SASS_INST6(GK110SASS_OPCODE6__IADD32I) +                          \
     BF_FLDV(GK110SASS_IMM32,imm32) +                                       \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGDEST,rd) +                                        \
     BF_FLDV(GK110SASS_32I_X,x) +                                           \
     BF_FLDV(GK110SASS_32I_WRITECC,cc) +                                    \
     BF_FLD(GK110SASS_32I_PSIGN,psign))

#define GK110SASS_INST_IADD32I(rd, ra, imm32)           GK110SASS_INST_IADD32I_FULL(0, NONE, 0, rd, ra, imm32)
#define GK110SASS_INST_IADD32I_CC(rd, ra, imm32)        GK110SASS_INST_IADD32I_FULL(0, NONE, 1, rd, ra, imm32)
#define GK110SASS_INST_IADD32I_X(rd, ra, imm32)         GK110SASS_INST_IADD32I_FULL(1, NONE, 0, rd, ra, imm32)
#define GK110SASS_INST_IADD32I_NEGA_CC(rd, ra, imm32)   GK110SASS_INST_IADD32I_FULL(0, NEGA, 1, rd, ra, imm32)

#define GK110SASS_INST_ATOM(op, rd, ra, k, r)                               \
    (GK110SASS_INST7(GK110SASS_OPCODE7__ATOM) +                             \
     BF_FLD(GK110SASS_ATOM_OP,op) +                                         \
     BF_FLD(GK110SASS_ATOM_SIZERA,U32) +                                    \
     BF_FLDV(GK110SASS_ATOM_IMM20, k) +                                     \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,r) +                                            \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_ATOM32(op, rd, ra, k, r)                             \
    (GK110SASS_INST7(GK110SASS_OPCODE7__ATOM) +                             \
     BF_FLD(GK110SASS_ATOM_OP,op) +                                         \
     BF_FLD(GK110SASS_ATOM_SIZERA,U32) +                                    \
     BF_FLDV(GK110SASS_ATOM_IMM20, k) +                                     \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,r) +                                            \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_ATOM32_X(op, rd, ra, k, r)                           \
    (GK110SASS_INST7(GK110SASS_OPCODE7__ATOM) +                             \
     BF_FLD(GK110SASS_ATOM_OP,op) +                                         \
     BF_FLD(GK110SASS_ATOM_SIZERA,U32) +                                    \
     BF_FLDV(GK110SASS_ATOM_IMM20, k) +                                     \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_ATOM_X,1) +                                          \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,r) +                                            \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_ATOM64(op, rd, ra, k, r)                             \
    (GK110SASS_INST7(GK110SASS_OPCODE7__ATOM) +                             \
     BF_FLD(GK110SASS_ATOM_OP,op) +                                         \
     BF_FLD(GK110SASS_ATOM_SIZERA,U64) +                                    \
     BF_FLDV(GK110SASS_ATOM_IMM20, k) +                                     \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,r) +                                            \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_ATOM64_X(op, rd, ra, k, r)                           \
    (GK110SASS_INST7(GK110SASS_OPCODE7__ATOM) +                             \
     BF_FLD(GK110SASS_ATOM_OP,op) +                                         \
     BF_FLD(GK110SASS_ATOM_SIZERA,U64) +                                    \
     BF_FLDV(GK110SASS_ATOM_IMM20, k) +                                     \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_ATOM_X,1) +                                          \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLDV(GK110SASS_REGB,r) +                                            \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_CCTL_IV(ra,k)                                        \
    (GK110SASS_INST7_3(MISC1, CCTL) +                                       \
     BF_FLDV(GK110SASS_IMM30, k) +                                          \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                        \
     BF_FLDV(GK110SASS_REGA,ra) +                                           \
     BF_FLD(GK110SASS_CACHE3,D) +                                           \
     BF_FLD(GK110SASS_COP4,IV))

#define GK110SASS_INST_CCTL_IVALL       0x7b000000001ffc1aULL
#define GK110SASS_INST_CCTL_IIVALL      0x7b000000001ffcdaULL
#define GK110SASS_INST_CCTLL_IVALL      0x7c000000001ffc1aULL
#define GK110SASS_INST_CCTLL_CRS_WBALL  0x7c000000001ffc62ULL

#define GK110SASS_INST_MEMBAR(lvl)                                          \
    (0x7cc0000000000002ULL +                                                \
     BF_FLD(GK110SASS_MEMBAR_LVL, lvl) +                                    \
     BF_FLDV(GK110SASS_SYNC,0) +                                            \
     BF_FLD(GK110SASS_PRED,UNCOND))

#define GK110SASS_INST_RTT              0x1b00000000000000ULL
#define GK110SASS_INST_RTT_TERMINATE    0x1b00000000000004ULL

#define GK110SASS_INST_BPT(mode, imm)                                       \
    (GK110SASS_INST5_6(CTRL, BPT) +                                         \
     BF_FLD(GK110SASS_BPT_MODE, mode) +                                     \
     BF_FLDV(GK110SASS_BPT_IMM20, imm))

#define GK110SASS_INST_TLD(rd, ra, ptrIdx)                               \
    (0x7000000000000002ULL +                                             \
     BF_FLD(GK110SASS_PRED,UNCOND) +                                     \
     BF_FLDV(GK110SASS_TEX_REGB,0xff) +                                  \
     BF_FLDV(GK110SASS_TEX_DIM,0) +                                      \
     BF_FLDV(GK110SASS_TEX_PTRIDX,ptrIdx) +                              \
     BF_FLDV(GK110SASS_REGA,ra) +                                        \
     BF_FLDV(GK110SASS_TEX_REGD,rd) +                                    \
     BF_FLDV(GK110SASS_TEX_WRITEMASK,0xf))

#define GK110SASS_INST_SHINT                                             \
    (GK110SASS_INST5_2(CTRL, SHINT))

#define GK110SASS_INST_TEXDEPBAR                                         \
    (0x7700000000000002ULL + BF_FLD(GK110SASS_PRED,UNCOND))

#define GK110SASS_INST_GETLMEMBASE(rd)                                   \
    (0x1680000000000000ULL +                                             \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_GETCRSPTR(rd)                                     \
    (0x1600000000000000ULL +                                             \
     BF_FLDV(GK110SASS_REGDEST,rd))

#define GK110SASS_INST_SULDGA_MASK   (GK110SASS_INST7_5_MASK)
#define GK110SASS_INST_SULDGA_OPCODE (GK110SASS_INST7_5(MISC1, SULDGA))

#define GK110SASS_INST_SULDGAI_MASK   (GK110SASS_INST7_MASK)
#define GK110SASS_INST_SULDGAI_OPCODE (GK110SASS_INST7(GK110SASS_OPCODE7__SULDGA))

// Instruction modifiers
#define GK110SASS_INST_PRED(p, inst) ((inst & ~BF_MASK(GK110SASS_PRED)) + BF_FLDV(GK110SASS_PRED,p))
#define GK110SASS_INST_CC(cc, inst) ((inst & ~BF_MASK(GK110SASS_CCC)) + BF_FLD(GK110SASS_CCC,cc))

#endif
