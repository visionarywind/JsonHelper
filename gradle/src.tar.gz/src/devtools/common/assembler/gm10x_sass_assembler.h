/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: gm10x_sass_assembler.h
 *
 *   Description:
 *       A Poor Man's inline GM10x SASS Assembler.
 *
 *
 ******************************************************************************/

#ifndef _GM10X_SASS_ASSEMBLER_H
#define _GM10X_SASS_ASSEMBLER_H

#include "sass_assembler.h"
#include "gm10x_sass.h"

#ifdef __linux__
//CUresult gm10x_sass_disassemble(const void *buf, size_t bufSize);
#endif

/* GM10x Instructions macros */
// To make the code easier to read
enum gm10x_sass_reg {  R0,   R1,   R2,   R3,   R4,   R5,   R6,   R7,
                       R8,   R9,  R10,  R11,  R12,  R13,  R14,  R15,
                       R16,  R17,  R18,  R19,  R20,  R21,  R22,  R23,
                       R24,  R25,  R26,  R27,  R28,  R29,  R30,  R31,
                       R32,  R33,  R34,  R35,  R36,  R37,  R38,  R39,
                       R40,  R41,  R42,  R43,  R44,  R45,  R46,  R47,
                       R48,  R49,  R50,  R51,  R52,  R53,  R54,  R55,
                       R56,  R57,  R58,  R59,  R60,  R61,  R62,  R63,
                       R64,  R65,  R66,  R67,  R68,  R69,  R70,  R71,
                       R72,  R73,  R74,  R75,  R76,  R77,  R78,  R79,
                       R80,  R81,  R82,  R83,  R84,  R85,  R86,  R87,
                       R88,  R89,  R90,  R91,  R92,  R93,  R94,  R95,
                       R96,  R97,  R98,  R99, R100, R101, R102, R103,
                       R104, R105, R106, R107, R108, R109, R110, R111,
                       R112, R113, R114, R115, R116, R117, R118, R119,
                       R120, R121, R122, R123, R124, R125, R126, R127,
                       R128, R129, R130, R131, R132, R133, R134, R135,
                       R136, R137, R138, R139, R140, R141, R142, R143,
                       R144, R145, R146, R147, R148, R149, R150, R151,
                       R152, R153, R154, R155, R156, R157, R158, R159,
                       R160, R161, R162, R163, R164, R165, R166, R167,
                       R168, R169, R170, R171, R172, R173, R174, R175,
                       R176, R177, R178, R179, R180, R181, R182, R183,
                       R184, R185, R186, R187, R188, R189, R190, R191,
                       R192, R193, R194, R195, R196, R197, R198, R199,
                       R200, R201, R202, R203, R204, R205, R206, R207,
                       R208, R209, R210, R211, R212, R213, R214, R215,
                       R216, R217, R218, R219, R220, R221, R222, R223,
                       R224, R225, R226, R227, R228, R229, R230, R231,
                       R232, R233, R234, R235, R236, R237, R238, R239,
                       R240, R241, R242, R243, R244, R245, R246, R247,
                       R248, R249, R250, R251, R252, R253, R254, R255,
                       RZ = 255
                    };

enum gm10x_sass_pred {P0, P1, P2, P3, P4, P5, P6, P7,
                      NOT_P0, NOT_P1, NOT_P2, NOT_P3, NOT_P4, NOT_P5, NOT_P6, NOT_P7,

                      // Aliases
                      PT = P7,
                      NOT_PT = NOT_P7
                     };

enum gm10x_sass_sreg {SR0, SR1, SR2, SR3, SR4, SR5, SR6, SR7,
                      SR8, SR9, SR10, SR11, SR12, SR13, SR14, SR15,
                      SR16, SR17, SR18, SR19, SR20, SR21, SR22, SR23,
                      SR24, SR25, SR26, SR27, SR28, SR29, SR30, SR31,
                      SR32, SR33, SR34, SR35, SR36, SR37, SR38, SR39,
                      SR40, SR41, SR42, SR43, SR44, SR45, SR46, SR47,
                      SR48, SR49, SR50, SR51, SR52, SR53, SR54, SR55,
                      SR56, SR57, SR58, SR59, SR60, SR61, SR62, SR63,
                      SR64, SR65, SR66, SR67, SR68, SR69, SR70, SR71,
                      SR72, SR73, SR74, SR75, SR76, SR77, SR78, SR79,
                      SR80, SR81, SR82, SR83
                     };

enum gm10x_sass_ldst_cops {
    COP_CA = GM10X_KEYWORD_LOADCACHEOP_CA,
    COP_CG = GM10X_KEYWORD_LOADCACHEOP_CG,
    COP_CS = GM10X_KEYWORD_LOADCACHEOP_CS,
    COP_CV = GM10X_KEYWORD_LOADCACHEOP_CV,
    COP_LU = GM10X_KEYWORD_LOADCACHEOP_LU,
};

enum gm10x_sass_e {
    E_NOE = GM10X_KEYWORD_E_NOE,
    E_E = GM10X_KEYWORD_E_E,
};

enum gm10x_sass_x {
    X_NOX = GM10X_KEYWORD_X_NOX,
    X_X = GM10X_KEYWORD_X_X,
};

enum gm10x_sass_cc {
    CC_NOCC = GM10X_KEYWORD_OPTCC_NOCC,
    CC_CC = GM10X_KEYWORD_OPTCC_CC,
};

enum gm10x_sass_sat {
    SAT_NOSAT = GM10X_KEYWORD_SAT_NOSAT,
};

enum gm10x_sass_vote_ops {
    VOTE_ALL = GM10X_KEYWORD_VOTEOP_ALL,
    VOTE_ANY = GM10X_KEYWORD_VOTEOP_ANY,
    VOTE_EQ  = GM10X_KEYWORD_VOTEOP_EQ,
};

enum gm10x_ldst_sizes {
    LDST_U8   = GM10X_KEYWORD_LDINTEGER_U8,
    LDST_S8   = GM10X_KEYWORD_LDINTEGER_S8,
    LDST_U16  = GM10X_KEYWORD_LDINTEGER_U16,
    LDST_S16  = GM10X_KEYWORD_LDINTEGER_S16,
    LDST_32   = GM10X_KEYWORD_LDINTEGER_32,
    LDST_64   = GM10X_KEYWORD_LDINTEGER_64,
    LDST_128  = GM10X_KEYWORD_LDINTEGER_128,
};

enum gm10x_atom_size {
    ATOM_U32 = GM10X_KEYWORD_SQINTEGER_U32,
    ATOM_S32 = GM10X_KEYWORD_SQINTEGER_S32,
    ATOM_U64 = GM10X_KEYWORD_SQINTEGER_U64,
    ATOM_S64 = GM10X_KEYWORD_SQINTEGER_S64,
    ATOM_F32_FTZ_RN = GM10X_KEYWORD_SQINTEGER_F32_FTZ_RN,
};

enum gm10x_sass_ccpr {
    CC = GM10X_KEYWORD_CCPR_CC,
    PR = GM10X_KEYWORD_CCPR_PR,
};

enum gm10x_sass_b3b0 {
    B3B0_B0 = GM10X_KEYWORD_B3B0_B0,
    B3B0_B1 = GM10X_KEYWORD_B3B0_B1,
    B3B0_B2 = GM10X_KEYWORD_B3B0_B2,
    B3B0_B3 = GM10X_KEYWORD_B3B0_B3,
};

enum gm10x_sass_inc {
    NOINC = GM10X_KEYWORD_INC_NOINC,
    INC = GM10X_KEYWORD_INC_INC,
};

enum gm10x_sass_lop {
    AND     = GM10X_KEYWORD_LOP_AND,
    OR      = GM10X_KEYWORD_LOP_OR,
    PASS_B  = GM10X_KEYWORD_LOP_PASS_B,
    XOR     = GM10X_KEYWORD_LOP_XOR,
};

enum gm10x_sass_icmpall {
    EQ  = GM10X_KEYWORD_ICMPALL_EQ,
    F   = GM10X_KEYWORD_ICMPALL_F,
    GE  = GM10X_KEYWORD_ICMPALL_GE,
    GT  = GM10X_KEYWORD_ICMPALL_GT,
    LE  = GM10X_KEYWORD_ICMPALL_LE,
    LT  = GM10X_KEYWORD_ICMPALL_LT,
    NE  = GM10X_KEYWORD_ICMPALL_NE,
    T   = GM10X_KEYWORD_ICMPALL_T,
};

enum gm10x_sass_membarlevel {
    CTA = GM10X_KEYWORD_MEMBARLEVEL_CTA,
    GL  = GM10X_KEYWORD_MEMBARLEVEL_GL,
    SYS = GM10X_KEYWORD_MEMBARLEVEL_SYS,
    VC  = GM10X_KEYWORD_MEMBARLEVEL_VC,
};

enum gm10x_sass_lod {
    LZ = GM10X_KEYWORD_LOD1_LZ,
    LL = GM10X_KEYWORD_LOD1_LL,
};

enum gm10x_sass_bop {
    BOP_AND     = GM10X_KEYWORD_BOP_AND,
    BOP_OR      = GM10X_KEYWORD_BOP_OR,
    BOP_XOR     = GM10X_KEYWORD_BOP_XOR,
};

enum gm10x_sass_atomop {
    ATOMOP_ADD     = GM10X_KEYWORD_ATOMOP_ADD,
    ATOMOP_MIN     = GM10X_KEYWORD_ATOMOP_MIN,
    ATOMOP_MAX     = GM10X_KEYWORD_ATOMOP_MAX,
    ATOMOP_INC     = GM10X_KEYWORD_ATOMOP_INC,
    ATOMOP_DEC     = GM10X_KEYWORD_ATOMOP_DEC,
    ATOMOP_AND     = GM10X_KEYWORD_ATOMOP_AND,
    ATOMOP_OR      = GM10X_KEYWORD_ATOMOP_OR,
    ATOMOP_XOR     = GM10X_KEYWORD_ATOMOP_XOR,
    ATOMOP_EXCH    = GM10X_KEYWORD_ATOMOP_EXCH,
    ATOMOP_SAFEADD = GM10X_KEYWORD_ATOMOP_SAFEADD,
};

enum gm10x_sass_inv {
    INV_NOINV      = GM10X_KEYWORD_UNARYINV_NOINV,
    INV_INV        = GM10X_KEYWORD_UNARYINV_INV,
};

#define _SET_PRED(new_pred, code) do { code; sassModifyLastInst(sass, BF_MASK(GM10X_FIELD_Pred), BF_FLDV(GM10X_FIELD_Pred,new_pred)); sassModifyLastInst(sass, BF_MASK(GM10X_FIELD_PredNot), BF_FLDV(GM10X_FIELD_PredNot, (new_pred >> 3)) ); } while (0)
#define IF_P0(code) _SET_PRED(P0,code)
#define IF_P1(code) _SET_PRED(P1,code)
#define IF_P2(code) _SET_PRED(P2,code)
#define IF_P3(code) _SET_PRED(P3,code)
#define IF_P4(code) _SET_PRED(P4,code)
#define IF_P5(code) _SET_PRED(P5,code)
#define IF_P6(code) _SET_PRED(P6,code)
#define IF_P7(code) _SET_PRED(P7,code)
#define IF_PT(code) _SET_PRED(P7,code)
#define IF_NOT_P0(code) _SET_PRED(NOT_P0,code)
#define IF_NOT_P1(code) _SET_PRED(NOT_P1,code)
#define IF_NOT_P2(code) _SET_PRED(NOT_P2,code)
#define IF_NOT_P3(code) _SET_PRED(NOT_P3,code)
#define IF_NOT_P4(code) _SET_PRED(NOT_P4,code)
#define IF_NOT_P5(code) _SET_PRED(NOT_P5,code)
#define IF_NOT_P6(code) _SET_PRED(NOT_P6,code)
#define IF_NOT_P7(code) _SET_PRED(NOT_P7,code)
#define IF_NOT_PT(code) _SET_PRED(NOT_P7,code)

// Helper values
#define BF_IMM(fldi) ((((BF_HI(fldi) - BF_LO(fldi) + 1) & 0xff) << 8)|(BF_LO(fldi)&0xff))

/* SASS assembly macros

   Organized according to
   https://p4viewer.nvidia.com/get///hw/doc/gpu/kepler/kepler/design/IAS/SML1/ISA/opcodes/IAS_Visible_ISA_Kepler.vsd
*/

/* Page 3 Kepler FP32/FP64 */
/* Page 4 Kepler Integer */
#define IMNMX        #error "Todo"
#define ISET         #error "Todo"
#define ISETP(cc,pd,ra,rb) sassAsmInst(sass,GM10X_INST_ISETP(cc,AND,pd,PT,ra,rb,PT, (PT>>3)))
#define ISETPI(cc,pd,ra,k) sassAsmInst(sass,GM10X_INST_ISETP_IMM(cc,AND,pd,PT,ra,k,PT, (PT>>3)))
#if 0
#define ISETP_FMT(cc, fmt, bop, x, pd, ra, rb, ps) sassAsmInst(sass,GM10X_INST_ISETP_FULL(PT, cc, x, bop, pd, PT, ra, rb, ps))

#define ISETPI(fmt, cc,pd,ra,k) sassAsmInst(sass,GM10X_INST_ISETP_NOBOP_IMM(fmt, cc,pd,ra,k))
#endif
#define ISETP_FMT  #error "Missing sign bit"

#define ISETP_X_AND  #error "Todo"
#define ISETP_AND    #error "Todo"


#define IMAD         #error "Todo"
#define BFI(rd,ra,fldi) sassAsmInst(sass,GM10X_INST_BFI_IMM(rd,ra,BF_IMM(fldi), rd)
#define ICMP(cc, rd, ra, rb, sc) sassAsmInst(sass,GM10X_INST_ICMP(cc, rd, ra, rb, sc))
#define ISAD         #error "Todo"
#define ISCADD       #error "Todo"

#define IADD(rd,ra,rb)      sassAsmInst(sass,GM10X_INST_IADD(rd,ra,rb))
#define IADD_CC(rd,ra,rb)   sassAsmInst(sass,GM10X_INST_IADD_ALL(PT, SAT_NOSAT, X_NOX, rd, CC_CC, ra,rb))
#define IADD_X(rd,ra,rb)   sassAsmInst(sass,GM10X_INST_IADD_ALL(PT, SAT_NOSAT, X_X, rd, CC_NOCC, ra,rb))
#define IADDI(rd,ra,k)      sassAsmInst(sass,GM10X_INST_IADD_IMM(rd,ra,k))
#define IADDI_CC            #error "Todo"
#define IADDI_X             #error "Todo"
#if 0
#define ISUB(rd,ra,rb)      sassAsmInst(sass,GM10X_INST_IADD_NEGB(rd,ra,rb))
#define ISUB_CC(rd,ra,rb)   sassAsmInst(sass,GM10X_INST_IADD_NEGB_CC(rd,ra,rb))
#define ISUB_X(rd,ra,rb)    sassAsmInst(sass,GM10X_INST_IADD_NEGB_X(rd,ra,rb))
#endif
#define ISUB  #error "Missing sign bit"
#define ISUB_CC  #error "Missing sign bit"
#define ISUB_X  #error "Missing sign bit"

#define IMUL(rd,ra,rb)          sassAsmInst(sass,GM10X_INST_IMUL(rd,ra,rb))
#define SHR(rd,ra,rb)           sassAsmInst(sass,GM10X_INST_SHR(rd,ra,rb))
#define SHRI(rd,ra,k)           sassAsmInst(sass,GM10X_INST_SHR_IMM(rd,ra,k))
#define SHL(rd,ra,rb)           sassAsmInst(sass,GM10X_INST_SHL(rd,ra,rb))
#define SHLI                    #error "Todo"
#define LOP(lop,rd,ra,rb)       sassAsmInst(sass,GM10X_INST_LOP(lop,rd,ra,INV_NOINV, rb, INV_NOINV))
#define LOP_NOTSB(lop,rd,ra,rb)       sassAsmInst(sass,GM10X_INST_LOP(lop,rd,ra,INV_NOINV, rb, INV_INV))
#define LOPI(lop,rd,ra,k)       sassAsmInst(sass,GM10X_INST_LOP_IMM(lop,rd,ra,INV_NOINV, k))
#define LOP_CC                  #error "Todo"
#define BFE(rd,ra,fldi)         sassAsmInst(sass,GM10X_INST_BFE_IMM(rd,ra,BF_IMM(fldi)))
#define FLO(rd,rb)              sassAsmInst(sass,GM10X_INST_FLO(rd,rb))

// Kepler Conversions/Bit
#define CSET         #error "Todo"
#define CSETP        #error "Todo"
#define PSET         #error "Todo"
#define PSETP(bop,pu,pp,pq) sassAsmInst(sass,GM10X_INST_PSETP(bop,BOP_AND,pu,PT,pp, (pp>>3), pq, (pq >> 3), PT, (PT>>3)))

#define F2F          #error "Todo"
#define F2I          #error "Todo"
#define I2F          #error "Todo"
#define I2I          #error "Todo"
#define SEL          #error "Todo"
#define PRMT         #error "Todo"
#define MOV(rd,rs)   sassAsmInst(sass,GM10X_INST_MOV(rd,rs))
#define S2R(rd,sr)   sassAsmInst(sass,GM10X_INST_S2R(rd,sr))
#define P2R(rd,ccpr,ra,k)      sassAsmInst(sass,GM10X_INST_P2R_IMM(rd, ccpr, ra, k))
#define P2R_INS(insert,rd,ccpr,ra,k)      sassAsmInst(sass,GM10X_INST_P2R_IMM_ALL(PT, insert, rd, ccpr, ra, k))
#define R2P(ccpr,ra)      sassAsmInst(sass,GM10X_INST_R2P_IMM(ccpr, ra))
#define R2P_EXT(ccpr,ra,extract,k)      sassAsmInst(sass,GM10X_INST_R2P_IMM_ALL(PT, ccpr, ra, extract, k))
#define B2R  #error "Deprecated. Use B2R_BAR, B2R_RESULT, B2R_WARP instead"
#define B2R_BAR(rd,name) sassAsmInst(sass,GM10X_INST_B2R_BAR(rd,name))
#define B2R_RESULT(rd) sassAsmInst(sass,GM10X_INST_B2R_RESULT(GM10X_KEYWORD_BARMD_RESULT,rd))
#define B2R_WARP(rd) sassAsmInst(sass,GM10X_INST_B2R_WARP(GM10X_KEYWORD_BARMD_WARP,rd))
#define R2B          #error "Todo"
#define NOP          sassAsmInst(sass,GM10X_INST_NOP)
#define NOP_S        #error "Does not exist. Use SYNC instead"
#define LEPC         #error "Todo"
#define VOTE(op, rd, pu, pp) sassAsmInst(sass,GM10X_INST_VOTE_ALL(PT, op, rd, pu, pp))
#define STP          #error "Todo"
#define BAR_SYNC     sassAsmInst(sass,GM10X_INST_BAR_SYNC_A_B(GM10X_KEYWORD_BARSYNC_SYNC,0))
#define BAR_SYNCALL  sassAsmInst(sass,GM10X_INST_BAR_SYNC_A_B(GM10X_KEYWORD_BARSYNCALL_SYNCALL,0))
#define POPC         #error "Todo"


// Kepler Conversion/Bit Encodings
/* Page 5 Video Integer */
/* Page 6 Kepler Memory Load/Store */
#define RED          #error "Todo"
#define ATOM(atomop,rd,ra,k,r) sassAsmInst(sass,GM10X_INST_ATOM_ALL(PT, E_NOE, atomop, ATOM_U32, rd, ra, k, r))
#define ATOM32(atomop,rd,ra,k,r) sassAsmInst(sass,GM10X_INST_ATOM_ALL(PT, E_NOE, atomop, ATOM_U32, rd, ra, k, r)
#define ATOM32_X(atomop,rd,ra,k,r) sassAsmInst(sass,GM10X_INST_ATOM_ALL(PT, E_E, atomop, ATOM_U32, rd, ra, k, r))
#define ATOM64(atomop,rd,ra,k,r) sassAsmInst(sass,GM10X_INST_ATOM_ALL(PT, E_NOE, atomop, ATOM_U64, rd, ra, k, r))
#define ATOM64_X(atomop,rd,ra,k,r) sassAsmInst(sass,GM10X_INST_ATOM_ALL(PT, E_E, atomop, ATOM_U64, rd, ra, k, r))

#define LD(rd,ra,k,plg)     sassAsmInst(sass,GM10X_INST_LD_ALL(PT, E_NOE, COP_CA, LDST_U32, rd, ra, k, plg))
#define LD32_E(rd,ra,k,plg) sassAsmInst(sass,GM10X_INST_LD_ALL(PT, E_E, COP_CA, LDST_U32, rd, ra, k, plg))
#define LD64(rd,ra,k)   sassAsmInst(sass,GM10X_INST_LD_ALL(PT, E_NOE, COP_CA, LDST_U64, rd, ra, k, plg))
#define LD64_E(rd,ra,k) sassAsmInst(sass,GM10X_INST_LD_ALL(PT, E_E, COP_CA, LDST_U64, rd, ra, k, plg))
#define LD128(rd,ra,k)  sassAsmInst(sass,GM10X_INST_LD_ALL(PT, E_NOE, COP_CA, LDST_128, rd, ra, k, plg))

#define LD_CG(rd,ra,k,plg)     sassAsmInst(sass,GM10X_INST_LD_ALL(PT, E_NOE, COP_CG, LDST_32, rd, ra, k, plg))
#define LD32_E_CG(rd,ra,k,plg) sassAsmInst(sass,GM10X_INST_LD_ALL(PT, E_E, COP_CG, LDST_32, rd, ra, k, plg))
#define LD64_CG(rd,ra,k,plg)   sassAsmInst(sass,GM10X_INST_LD_ALL(PT, E_NOE, COP_CG, LDST_64, rd, ra, k, plg))
#define LD64_E_CG(rd,ra,k,plg) sassAsmInst(sass,GM10X_INST_LD_ALL(PT, E_E, COP_CG, LDST_64, rd, ra, k, plg))
#define LD128_CG(rd,ra,k,plg)  sassAsmInst(sass,GM10X_INST_LD_ALL(PT, E_NOE, COP_CG, LDST_128, rd, ra, k, plg))

#define LDU             #error "Todo"
#define ST(ra,k,r,plg)      sassAsmInst(sass,GM10X_INST_ST_ALL(PT, E_NOE, COP_CA, LDST_32, ra, k, r, plg))
#define ST32_X(ra,k,r,plg)  sassAsmInst(sass,GM10X_INST_ST_ALL(PT, E_E, COP_CA, LDST_32, ra, k, r, plg))
#define ST64(ra,k,r,plg)    sassAsmInst(sass,GM10X_INST_ST_ALL(PT, E_NOE, COP_CA, LDST_64, ra, k, r, plg))
#define ST64_X(ra,k,r,plg)  sassAsmInst(sass,GM10X_INST_ST_ALL(PT, E_E, COP_CA, LDST_64, ra, k, r, plg))
#define ST128(ra,k,r,plg)  sassAsmInst(sass,GM10X_INST_ST_ALL(PT, E_NOE, COP_CA, LDST_128, ra, k, r, plg))
#define CCTL_IVALL      sassAsmInst(sass,GM10X_INST_CCTL_IVALL(GM10X_KEYWORD_CCTLOP_IV))
#define CCTL_IV  #error "Todo"
#define LDLK         #error "Todo"
#define LDS_LDU      #error "Todo"
#define LDL16(rd,ra,k) sassAsmInst(sass,GM10X_INST_LDL_ALL(PT, COP_CA, LDST_U16, rd, ra, k))
#define LDL(rd,ra,k) sassAsmInst(sass,GM10X_INST_LDL_ALL(PT, COP_CA, LDST_32, rd, ra, k))
#define LDL128(rd,ra,k) sassAsmInst(sass,GM10X_INST_LDL_ALL(PT, COP_CA, LDST_128, rd, ra, k))
#define LDS(rd,ra,k) sassAsmInst(sass,GM10X_INST_LDS_ALL(PT, GM10X_KEYWORD_LDSINTEGER_32, rd, ra, k))
#define LDS128(rd,ra,k) sassAsmInst(sass,GM10X_INST_LDS_ALL(PT, GM10X_KEYWORD_LDSINTEGER_128, rd, ra, k))
#define LDSLK        #error "Todo"
#define STL16(ra,k,r)  sassAsmInst(sass,GM10X_INST_STL_ALL(PT, COP_CA, LDST_U16, ra, k, r))
#define STL(ra,k,r)  sassAsmInst(sass,GM10X_INST_STL_ALL(PT, COP_CA, LDST_32, ra, k, r))
#define STL64(ra,k,r) sassAsmInst(sass,GM10X_INST_STL_ALL(PT, COP_CA, LDST_64, ra, k, r))
#define STL128(ra,k,r) sassAsmInst(sass,GM10X_INST_STL_ALL(PT, COP_CA, LDST_128, ra, k, r))
#define STS(ra,k,r)  sassAsmInst(sass,GM10X_INST_STS_ALL(PT, LDST_32, ra, k, r))
#define STS64(ra,k,r)  sassAsmInst(sass,GM10X_INST_STS_ALL(PT, LDST_64, ra, k, r))
#define STS128(ra,k,r)  sassAsmInst(sass,GM10X_INST_STS_ALL(PT, LDST_128, ra, k, r))
#define STSUL        #error "Todo"
#define CCTLL_IVALL  sassAsmInst(sass,GM10X_INST_CCTLL_I(GM10X_KEYWORD_CCTLLOP2_IVALL))
#define CCTLL_CRS_WBALL sassAsmInst(sass,GM10X_INST_CCTLL_CRS_WBALL(GM10X_KEYWORD_CRSONLY_CRS, GM10X_KEYWORD_CCTLLOP3_WBALL))
#define SULD         #error "Todo"
#define SURED        #error "Todo"
#define SUST         #error "Todo"
#define MEMBAR(lvl)  sassAsmInst(sass,GM10X_INST_MEMBAR(lvl))
#define SUQ          #error "Todo"
#define STUL         #error "Todo"
#define SUATOM       #error "Todo"
#define STLEA        #error "Todo"
#define WTEST        #error "Todo"

/* Page 7 GFX Load/Store */
#define LDC(rd,bank,k)  sassAsmInst(sass,GM10X_INST_LDC_ALL(PT,GM10X_KEYWORD_CINTEGER_N64_N128_32, GM10X_KEYWORD_ADMODE_IA, rd,bank,RZ, k))
// Kepler Texture
#define TLD(rd,ra,tid,paramA)  sassAsmInst(sass,GM10X_INST_TLD(LZ, rd, ra, tid, paramA))
#define TEXDEPBAR         #error "Deprecated. Use DEPBAR instead"
/* Page 8 Kepler Branch/Misc */

// Absolute
#define JMP_A(target)  sassAsmInst(sass,GM10X_INST_JMP(target))
#define JMP_C(bank,k)  sassAsmInst(sass,GM10X_INST_JMP_C_ALL(PT, GM10X_KEYWORD_U_NOU, GM10X_KEYWORD_LMT_NOLMT, GM10X_KEYWORD_TEST_T, bank, k)

#define JMX            #error "Todo"
#define JCAL(target)   sassAsmInst(sass,GM10X_INST_JCAL(target))

// Relative
#define BRA(target)    sassAsmInst(sass,GM10X_INST_BRA(target - sass->codePointer - 8))
#define BRX            #error "Todo"
#define CAL            #error "Todo"
#define PLONGJMP(target) sassAsmInst(sass,GM10X_INST_PLONGJMP(target - sass->codePointer - 8))
#define SSY(target)    sassAsmInst(sass,GM10X_INST_SSY(target - sass->codePointer - 8))
#define PBK            #error "Todo"
#define PCNT           #error "Todo"
#define PRET(target,inc) sassAsmInst(sass,GM10X_INST_PRET(target - sass->codePointer - 8,inc))

#define EXIT           #error "Todo"
#define LONGJML        #error "Todo"
#define RET            sassAsmInst(sass,GM10X_INST_RET)
#define KIL            #error "Todo"
#define RTT            sassAsmInst(sass,GM10X_INST_RTT)
#define RTT_TERMINATE  sassAsmInst(sass,GM10X_INST_RTT_ALL(GM10X_KEYWORD_RTTOP_TERMINATE))
#define BRK            #error "Todo"
#define CONT           #error "Todo"

#define SAM            #error "Todo"
#define RAM            #error "Todo"
#define BPT_PAUSE      sassAsmInst(sass,GM10X_INST_BPT(GM10X_KEYWORD_BPTMODE_PAUSE))
#define BPT_TRAP(imm)  sassAsmInst(sass,GM10X_INST_BPT_ALL(GM10X_KEYWORD_BPTMODE_TRAP,imm))
#define BPT_INT        sassAsmInst(sass,GM10X_INST_BPT(GM10X_KEYWORD_BPTMODE_INT))
#define BPT_DRAIN      sassAsmInst(sass,GM10X_INST_BPT(GM10X_KEYWORD_BPTMODE_DRAIN))

/* Page 9 Kepler 32I */
#define IMAD32I                     #error "Todo"
#define IADD32I(ra,rd,k)            sassAsmInst(sass,GM10X_INST_IADD32I(ra,rd,k))
#define IADD32I_CC(ra,rd,k)         sassAsmInst(sass,GM10X_INST_IADD32I_ALL(PT, SAT_NOSAT, X_NOX, ra, CC_CC, rd, k))
#define IADD32I_X(ra,rd,k)          sassAsmInst(sass,GM10X_INST_IADD32I_ALL(PT, SAT_NOSAT, X_X, ra, CC_NOCC, rd, k))
#if 0
#define IADD32I_NEGA_CC(ra,rd,k)    sassAsmInst(sass,GM10X_INST_IADD32I_NEGA_CC(ra,rd,k))
#endif
#define IADD32I_NEGA_CC  #error "Missing sign bits"

#define IMUL32I(ra,rd,k) sassAsmInst(sass,GM10X_INST_IMUL32I(ra,rd,k))
#define MOV32I(rd,k)   sassAsmInst(sass,GM10X_INST_MOV32I(rd,k))
#define FFMA32I        #error "Todo"
#define FADD32I        #error "Todo"
#define FMUL32I        #error "Todo"
#define LOP32I(lop,rd,ra,k)  sassAsmInst(sass,GM10X_INST_LOP32I(lop,rd,ra, INV_NOINV, k))
#define ISCADD32I      #error "Todo"

#define GETLMEMBASE(rd) sassAsmInst(sass,GM10X_INST_GETLMEMBASE(rd))
#define GETCRSPTR(rd) sassAsmInst(sass,GM10X_INST_GETCRSPTR(rd))

/* Used for Workaround for bug 840133 - If the sm instruction prefetcher isn't
   occupied with at least 320 bytes of nop's after a ret, it may be
   possible for it to take a branch to invalid instruction memory
   and trigger an MMU fault */
#define NOP_PAD(nop_count)                                                     \
do {                                                                           \
    NvU32 i;                                                                   \
    for (i = 0; i < nop_count; i++) {                                          \
        NOP;                                                                   \
    }                                                                          \
} while (0)

// maxwell opex fields
#define GM10X_OPEX_FIELD_USchedInfo 4:0
#define GM10X_OPEX_FIELD_Dest       7:5
#define GM10X_OPEX_FIELD_SrcRelease 10:8
#define GM10X_OPEX_FIELD_WaitOnSb   16:11

#define GM10X_OPEX_FIELD_TexPhase   18:17
#define GM10X_OPEX_FIELD_Reserved0  20:19

#define GM10X_OPEX_FIELD_ReuseA     17:17
#define GM10X_OPEX_FIELD_ReuseB     18:18
#define GM10X_OPEX_FIELD_ReuseC     19:19
#define GM10X_OPEX_FIELD_Reserved1  20:20

// maxwell opex encoding helper macros
#define GM10X_SASS_OPEX_SLOT(inst) (20+inst*21):(inst*21)

#define GM10X_SASS_SET_OPEX_ALL(base, inst, value) \
    (BF_SETFLDV(base, GM10X_SASS_OPEX_SLOT(inst), value))

#define GM10X_SASS_SET_OPEX(base, inst, field, value) \
    (BF_SETFLDV(base, GM10X_SASS_OPEX_SLOT(inst), BF_FLDV(field,value)))

#define GM10X_OPEX_OFF_DECK_DRAIN \
    (BF_FLDV(GM10X_OPEX_FIELD_USchedInfo, 0) | \
     BF_FLDV(GM10X_OPEX_FIELD_Dest, 7) | \
     BF_FLDV(GM10X_OPEX_FIELD_SrcRelease, 7))

#endif // _GM10X_SASS_ASSEMBLER_H
