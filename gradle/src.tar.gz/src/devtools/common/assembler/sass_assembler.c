/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: sass_assembler.c
 *
 *   Description:
 *       A Poor Man's inline SASS Assembler.
 *
 *
 ******************************************************************************/

#include <cuos.h> // Here for uintptr_t on MODS, needed by sass_assembler.h

#include "sass_assembler.h"
#include "cuda_structs.h"
#include "cuos_debug.h"
#include <string.h>

CUresult sass_assemble(void (*pass)(Sass_t, void *), void *passArgs, void *buf, size_t bufSize, size_t *usedSize, SassSymtab *symTab, uint32_t sm_major, uint32_t sm_minor)
{
    int n;
    SassCodeAddr endPC;
    struct Sass_st sass_st = {0};
    for (n = 1; n <= 2; ++n) {
        sassBegin(&sass_st, 0, (uint64_t *)buf, bufSize, symTab, sm_major, sm_minor);
        pass(&sass_st, passArgs);
        sassEnd(&sass_st, &endPC, usedSize);
        if (bufSize < *usedSize)
            return CUDA_ERROR_OUT_OF_MEMORY;
    }

    return CUDA_SUCCESS;
}

CUresult sass_symbol_offset(uint64_t *labelOffset, const char *labelName, SassSymtab *symTab)
{
    uint32_t i;

    if (!labelName || !labelOffset || !symTab)
        return CUDA_ERROR_INVALID_VALUE;

    for (i = 0; i < symTab->index; i++) {
        if (!strncmp(symTab->symEntry[i].symName, labelName, SASS_MAX_LABEL_LENGTH)) {
            *labelOffset = symTab->symEntry[i].offset;
            break;
        }
    }

    if (i == symTab->index) {
        CU_DEBUG_PRINT(("Cannot find symbol name in sass symbol table\n"));
        return CUDA_ERROR_UNKNOWN;
    }

    return CUDA_SUCCESS;
}


#ifdef __linux__
#ifndef RELEASE
static const char cubinHeader[] = "architecture {sm_%u}\n"
                                  "abiversion   {1}\n"
                                  "cubinversion {1}\n"
                                  "modname      {cubin}\n"
                                  "texmode      {texmode_unified}\n"
                                  "code {\n"
                                  "       name = kernel\n"
                                  "       lmem = 0\n"
                                  "       smem = 24\n"
                                  "       reg  = 1\n"
                                  "       bar  = 0\n"
                                  "       ctaidZUsed  = 0\n"
                                  "       params_SMEM {\n"
                                  "               0x00000000 0x00000004 \n"
                                  "       }\n"
                                  "       bincode {\n"
                                  ;
#else
static const char cubinHeader[] = "%u";
#endif /* RELEASE */
#endif /* __linux__ */

#ifdef __linux__
#include <stdio.h>

static CUresult printCubin(const char *name, const uint32_t *code, size_t codeSize, const char *cubinHeader)
{
    unsigned i;
    FILE *f = fopen(name, "w");

    if (!f)
        return CUDA_ERROR_FILE_NOT_FOUND;

    fprintf(f,"%s", cubinHeader);

    for (i = 0; i < codeSize / 4; i += 2)
        fprintf(f, "%#.8x %#.8x\n", code[i], code[i+1]);

    fprintf(f,
            "       }\n"
            "}\n");

    fclose(f);
    fflush(f);

    return CUDA_SUCCESS;
}

void dumpCubin(char *name, const uint32_t *code, size_t codeSize, uint32_t sm_ver)
{
    size_t headerLen = strlen(cubinHeader) + 32;
    char *header = (char *)calloc(headerLen, 1);

    snprintf(header, headerLen, cubinHeader, sm_ver);
    printCubin(name, code, codeSize, header);
    free(header);

}

void dumpCubinRaw(char *name, const uint64_t *code, size_t size)
{
    FILE *f = fopen(name, "w");

    if (!f)
        return;

    fwrite((void*)code, sizeof(*code), ((size_t)size)/sizeof(*code), f);

    fclose(f);
    fflush(f);

}

void sass_disassemble(const void *code, size_t codeSize, const char *cubinHeader)
{
    printCubin("/tmp/tmp.cubin", (const uint32_t *)code, codeSize, cubinHeader);
    system("fatdump -sass /tmp/tmp.cubin");
}

#endif
