/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: gk11x_sass_assembler.h
 *
 *   Description:
 *       A Poor Man's inline GK11x SASS Assembler.
 *
 *
 ******************************************************************************/

#ifndef _GK11X_SASS_ASSEMBLER_H
#define _GK11X_SASS_ASSEMBLER_H

#include "sass_assembler.h"
#include "gk11x_sass.h"

#ifdef __linux__
CUresult gk11x_sass_disassemble(const void *buf, size_t bufSize);
#endif

/* GK11x Instructions macros */
// To make the code easier to read
enum gk11x_sass_reg {  R0,   R1,   R2,   R3,   R4,   R5,   R6,   R7,
                       R8,   R9,  R10,  R11,  R12,  R13,  R14,  R15,
                       R16,  R17,  R18,  R19,  R20,  R21,  R22,  R23,
                       R24,  R25,  R26,  R27,  R28,  R29,  R30,  R31,
                       R32,  R33,  R34,  R35,  R36,  R37,  R38,  R39,
                       R40,  R41,  R42,  R43,  R44,  R45,  R46,  R47,
                       R48,  R49,  R50,  R51,  R52,  R53,  R54,  R55,
                       R56,  R57,  R58,  R59,  R60,  R61,  R62,  R63,
                       R64,  R65,  R66,  R67,  R68,  R69,  R70,  R71,
                       R72,  R73,  R74,  R75,  R76,  R77,  R78,  R79,
                       R80,  R81,  R82,  R83,  R84,  R85,  R86,  R87,
                       R88,  R89,  R90,  R91,  R92,  R93,  R94,  R95,
                       R96,  R97,  R98,  R99, R100, R101, R102, R103,
                       R104, R105, R106, R107, R108, R109, R110, R111,
                       R112, R113, R114, R115, R116, R117, R118, R119,
                       R120, R121, R122, R123, R124, R125, R126, R127,
                       R128, R129, R130, R131, R132, R133, R134, R135,
                       R136, R137, R138, R139, R140, R141, R142, R143,
                       R144, R145, R146, R147, R148, R149, R150, R151,
                       R152, R153, R154, R155, R156, R157, R158, R159,
                       R160, R161, R162, R163, R164, R165, R166, R167,
                       R168, R169, R170, R171, R172, R173, R174, R175,
                       R176, R177, R178, R179, R180, R181, R182, R183,
                       R184, R185, R186, R187, R188, R189, R190, R191,
                       R192, R193, R194, R195, R196, R197, R198, R199,
                       R200, R201, R202, R203, R204, R205, R206, R207,
                       R208, R209, R210, R211, R212, R213, R214, R215,
                       R216, R217, R218, R219, R220, R221, R222, R223,
                       R224, R225, R226, R227, R228, R229, R230, R231,
                       R232, R233, R234, R235, R236, R237, R238, R239,
                       R240, R241, R242, R243, R244, R245, R246, R247,
                       R248, R249, R250, R251, R252, R253, R254, R255,
                       RZ = 255
                    };

enum gk11x_sass_pred {P0, P1, P2, P3, P4, P5, P6, P7,
                      NOT_P0, NOT_P1, NOT_P2, NOT_P3, NOT_P4, NOT_P5, NOT_P6, NOT_P7,

                      // Aliases
                      PT = P7,
                      NOT_PT = NOT_P7
                     };

enum gk11x_sass_sreg {SR0, SR1, SR2, SR3, SR4, SR5, SR6, SR7,
                      SR8, SR9, SR10, SR11, SR12, SR13, SR14, SR15,
                      SR16, SR17, SR18, SR19, SR20, SR21, SR22, SR23,
                      SR24, SR25, SR26, SR27, SR28, SR29, SR30, SR31,
                      SR32, SR33, SR34, SR35, SR36, SR37, SR38, SR39,
                      SR40, SR41, SR42, SR43, SR44, SR45, SR46, SR47,
                      SR48, SR49, SR50, SR51, SR52, SR53, SR54, SR55,
                      SR56, SR57, SR58, SR59, SR60, SR61, SR62, SR63,
                      SR64, SR65, SR66, SR67, SR68, SR69, SR70, SR71,
                      SR72, SR73, SR74, SR75, SR76, SR77, SR78, SR79,
                      SR80, SR81, SR82, SR83
                     };

#define _SET_PRED(new_pred, code) do { code; sassModifyLastInst(sass, BF_MASK(GK110SASS_PRED), BF_FLDV(GK110SASS_PRED,new_pred)); } while (0)
#define IF_P0(code) _SET_PRED(P0,code)
#define IF_P1(code) _SET_PRED(P1,code)
#define IF_P2(code) _SET_PRED(P2,code)
#define IF_P3(code) _SET_PRED(P3,code)
#define IF_P4(code) _SET_PRED(P4,code)
#define IF_P5(code) _SET_PRED(P5,code)
#define IF_P6(code) _SET_PRED(P6,code)
#define IF_P7(code) _SET_PRED(P7,code)
#define IF_PT(code) _SET_PRED(P7,code)
#define IF_NOT_P0(code) _SET_PRED(NOT_P0,code)
#define IF_NOT_P1(code) _SET_PRED(NOT_P1,code)
#define IF_NOT_P2(code) _SET_PRED(NOT_P2,code)
#define IF_NOT_P3(code) _SET_PRED(NOT_P3,code)
#define IF_NOT_P4(code) _SET_PRED(NOT_P4,code)
#define IF_NOT_P5(code) _SET_PRED(NOT_P5,code)
#define IF_NOT_P6(code) _SET_PRED(NOT_P6,code)
#define IF_NOT_P7(code) _SET_PRED(NOT_P7,code)
#define IF_NOT_PT(code) _SET_PRED(NOT_P7,code)

/* WARNING: DO NOT USE ON NOP! Its CC field is in a different place */
#define _SET_CC(new_cc, code) do { code; sassModifyLastInst(sass, BF_MASK(GK110SASS_CCC), BF_FLD(GK110SASS_CCC,new_cc)); } while (0)
#define IF_CC(cc, code) _SET_CC(cc, code)

#define _SET_S(code) do { code; sassModifyLastInst(sass, BF_MASK(GK110SASS_SYNC), BF_FLDV(GK110SASS_SYNC,1)); } while (0)

// Helper values
#define IMM    BF_FLDV(GK110SASS_ABC,3)
#define CC     BF_FLDV(GK110SASS_WRITE_CC,1)
#define SIGNED BF_FLDV(5:5,1) // The u/s bit
#define SIGNED_MUL SIGNED+BF_FLDV(7:7,1) // B:u/s + A:u/s
#define BF_IMM(fldi) ((((BF_HI(fldi) - BF_LO(fldi) + 1) & 0xff) << 8)|(BF_LO(fldi)&0xff))

/* SASS assembly macros

   Organized according to
   https://p4viewer.nvidia.com/get///hw/doc/gpu/kepler/kepler/design/IAS/SML1/ISA/opcodes/IAS_Visible_ISA_Kepler.vsd
*/

/* Page 3 Kepler FP32/FP64 */
/* Page 4 Kepler Integer */
#define IMNMX        #error "Todo"
#define ISET         #error "Todo"
#define ISETP(cc,pd,ra,rb) sassAsmInst(sass,GK110SASS_INST_ISETP(cc,pd,ra,rb))
#define ISETP_FMT(cc, fmt, bop, x, pd, ra, rb, ps) sassAsmInst(sass,GK110SASS_INST_ISETP_FULL_FMT(cc, fmt, bop, x, pd, ra, rb, ps))

#define ISETPI(fmt, cc,pd,ra,k) sassAsmInst(sass,GK110SASS_INST_ISETPI(fmt, cc,pd,ra,k))
#define ISETP_X_AND  #error "Todo"
#define ISETP_AND    #error "Todo"


#define IMAD         #error "Todo"
#define BFI(rd,ra,fldi) sassAsmInst(sass,GK110SASS_INST_BFII(rd,ra,rd,BF_IMM(fldi)))
#define ICMP(cc, rd, ra, rb, sc) sassAsmInst(sass,GK110SASS_INST_ICMP(cc, rd, ra, rb, sc))
#define ISAD         #error "Todo"
#define ISCADD       #error "Todo"

#define IADD(rd,ra,rb)      sassAsmInst(sass,GK110SASS_INST_IADD(rd,ra,rb))
#define IADD_CC(rd,ra,rb)   sassAsmInst(sass,GK110SASS_INST_IADD_CC(rd,ra,rb))
#define IADD_X(rd,ra,rb)    sassAsmInst(sass,GK110SASS_INST_IADD_X(rd,ra,rb))
#define IADDI(rd,ra,k)      sassAsmInst(sass,GK110SASS_INST_IADDI(rd,ra,k))
#define IADDI_CC            #error "Todo"
#define IADDI_X             #error "Todo"
#define ISUB(rd,ra,rb)      sassAsmInst(sass,GK110SASS_INST_IADD_NEGB(rd,ra,rb))
#define ISUB_CC(rd,ra,rb)   sassAsmInst(sass,GK110SASS_INST_IADD_NEGB_CC(rd,ra,rb))
#define ISUB_X(rd,ra,rb)    sassAsmInst(sass,GK110SASS_INST_IADD_NEGB_X(rd,ra,rb))


#define IMUL(rd,ra,rb)          sassAsmInst(sass,GK110SASS_INST_IMUL(rd,ra,rb))
#define SHR                     #error "Todo"
#define SHRI(rd,ra,k)           sassAsmInst(sass,GK110SASS_INST_SHRI(rd,ra,k))
#define SHL(rd,ra,rb)           sassAsmInst(sass,GK110SASS_INST_SHL(rd,ra,rb))
#define SHLI                    #error "Todo"
#define LOP(lop,rd,ra,rb)       sassAsmInst(sass,GK110SASS_INST_LOP(lop,rd,ra,rb))
#define LOP_NOTSB(lop,rd,ra,rb) sassAsmInst(sass,GK110SASS_INST_LOP_NOTSB(lop,rd,ra,rb))
#define LOPI(lop,rd,ra,k)       sassAsmInst(sass,GK110SASS_INST_LOPI(lop,rd,ra,k))
#define LOP_CC                  #error "Todo"
#define BFE(rd,ra,fldi)         sassAsmInst(sass,GK110SASS_INST_BFEI(rd,ra,BF_IMM(fldi)))
#define FLO(rd,rb)              sassAsmInst(sass,GK110SASS_INST_FLO(rd,rb))

// Kepler Conversions/Bit
#define CSET         #error "Todo"
#define CSETP        #error "Todo"
#define PSET         #error "Todo"
#define PSETP(cc,pu,pp,pq) sassAsmInst(sass,GK110SASS_INST_PSETP(cc,pu,pp,pq))

#define F2F          #error "Todo"
#define F2I          #error "Todo"
#define I2F          #error "Todo"
#define I2I          #error "Todo"
#define SEL          #error "Todo"
#define PRMT         #error "Todo"
#define MOV(rd,rs)   sassAsmInst(sass,GK110SASS_INST_MOV(rd,rs))
#define S2R(rd,sr)   sassAsmInst(sass,GK110SASS_INST_S2R(rd,sr))
#define P2R(ra)      sassAsmInst(sass,GK110SASS_INST_P2R(ra))
#define R2P(ra)      sassAsmInst(sass,GK110SASS_INST_R2P(ra))
#define B2R(type,rd,name) sassAsmInst(sass,GK110SASS_INST_B2R(type,rd,name))
#define R2B          #error "Todo"
#define NOP          sassAsmInst(sass,GK110SASS_INST_NOP(0))
#define NOP_S        sassAsmInst(sass,GK110SASS_INST_NOP(1))
#define LEPC         #error "Todo"
#define VOTE(op, rd, pu, pp) sassAsmInst(sass,GK110SASS_INST_VOTE(op, rd, pu, pp))
#define STP          #error "Todo"
#define BAR_SYNC     sassAsmInst(sass,GK110SASS_INST_BAR(IMMNAME_IMMCOUNT,SYNC,0,0,OR))
#define BAR_SYNCALL  sassAsmInst(sass,GK110SASS_INST_BAR(IMMNAME_IMMCOUNT,SYNCALL,0,0,OR))
#define POPC         #error "Todo"


// Kepler Conversion/Bit Encodings
/* Page 5 Video Integer */
/* Page 6 Kepler Memory Load/Store */
#define RED          #error "Todo"
#define ATOM(op,rd,ra,k,r) sassAsmInst(sass,GK110SASS_INST_ATOM(op,rd,ra,k,r))
#define ATOM32(op,rd,ra,k,r) sassAsmInst(sass,GK110SASS_INST_ATOM32(op,rd,ra,k,r))
#define ATOM32_X(op,rd,ra,k,r) sassAsmInst(sass,GK110SASS_INST_ATOM32_X(op,rd,ra,k,r))
#define ATOM64(op,rd,ra,k,r) sassAsmInst(sass,GK110SASS_INST_ATOM64(op,rd,ra,k,r))
#define ATOM64_X(op,rd,ra,k,r) sassAsmInst(sass,GK110SASS_INST_ATOM64_X(op,rd,ra,k,r))

#define LD(rd,ra,k)     sassAsmInst(sass,GK110SASS_INST_LD(rd,ra,k))
#define LD32_X(rd,ra,k) sassAsmInst(sass,GK110SASS_INST_LD32_X(rd,ra,k))
#define LD64(rd,ra,k)   sassAsmInst(sass,GK110SASS_INST_LD64(rd,ra,k))
#define LD64_X(rd,ra,k) sassAsmInst(sass,GK110SASS_INST_LD64_X(rd,ra,k))
#define LD128(rd,ra,k)  sassAsmInst(sass,GK110SASS_INST_LD128(rd,ra,k))

#define LD_CG(rd,ra,k)     sassAsmInst(sass,GK110SASS_INST_LD_CG(rd,ra,k))
#define LD32_X_CG(rd,ra,k) sassAsmInst(sass,GK110SASS_INST_LD32_X_CG(rd,ra,k))
#define LD64_CG(rd,ra,k)   sassAsmInst(sass,GK110SASS_INST_LD64_CG(rd,ra,k))
#define LD64_X_CG(rd,ra,k) sassAsmInst(sass,GK110SASS_INST_LD64_X_CG(rd,ra,k))
#define LD128_CG(rd,ra,k)  sassAsmInst(sass,GK110SASS_INST_LD128_CG(rd,ra,k))

#define LDU             #error "Todo"
#define ST(ra,k,r)      sassAsmInst(sass,GK110SASS_INST_ST(ra,k,r))
#define ST32_X(ra,k,r)  sassAsmInst(sass,GK110SASS_INST_ST32_X(ra,k,r))
#define ST64(ra,k,r)    sassAsmInst(sass,GK110SASS_INST_ST64(ra,k,r))
#define ST64_X(ra,k,r)  sassAsmInst(sass,GK110SASS_INST_ST64_X(ra,k,r))
#define ST128           #error "Todo"
#define CCTL_IIVALL     sassAsmInst(sass,GK110SASS_INST_CCTL_IIVALL)
#define CCTL_IVALL      sassAsmInst(sass,GK110SASS_INST_CCTL_IVALL)
#define CCTL_IV(ra,k)   sassAsmInst(sass,GK110SASS_INST_CCTL_IV(ra,k))
#define LDLK         #error "Todo"
#define LDS_LDU      #error "Todo"
#define LDL16(rd,ra,k) sassAsmInst(sass,GK110SASS_INST_LDL16(rd,ra,k))
#define LDL(rd,ra,k) sassAsmInst(sass,GK110SASS_INST_LDL(rd,ra,k))
#define LDL128       #error "Todo"
#define LDS(rd,ra,k) sassAsmInst(sass,GK110SASS_INST_LDS(rd,ra,k))
#define LDS128(rd,ra,k) sassAsmInst(sass,GK110SASS_INST_LDS128(rd,ra,k))
#define LDSLK        #error "Todo"
#define STL16(ra,k,r)  sassAsmInst(sass,GK110SASS_INST_STL16(ra,k,r))
#define STL(ra,k,r)  sassAsmInst(sass,GK110SASS_INST_STL(ra,k,r))
#define STL64        #error "Todo"
#define STL128       #error "Todo"
#define STS(ra,k,r)  sassAsmInst(sass,GK110SASS_INST_STS(ra,k,r))
#define STS128(ra,k,r) sassAsmInst(sass,GK110SASS_INST_STS128(ra,k,r))
#define STSUL        #error "Todo"
#define CCTLL_IVALL  sassAsmInst(sass,GK110SASS_INST_CCTLL_IVALL)
#define CCTLL_CRS_WBALL sassAsmInst(sass,GK110SASS_INST_CCTLL_CRS_WBALL)
#define SULD         #error "Todo"
#define SURED        #error "Todo"
#define SUST         #error "Todo"
#define MEMBAR(lvl)  sassAsmInst(sass,GK110SASS_INST_MEMBAR(lvl))
#define SUQ          #error "Todo"
#define STUL         #error "Todo"
#define SUATOM       #error "Todo"
#define STLEA        #error "Todo"
#define WTEST        #error "Todo"

/* Page 7 GFX Load/Store */
#define LDC(rd,bank,k)  sassAsmInst(sass,GK110SASS_INST_LDC(rd,bank,k))
// Kepler Texture
#define TLD(rd,ra,ptrIdx) sassAsmInst(sass,GK110SASS_INST_TLD(rd,ra,ptrIdx))
#define TEXDEPBAR         sassAsmInst(sass,GK110SASS_INST_TEXDEPBAR)
/* Page 8 Kepler Branch/Misc */

// Absolute
#define JMP_A(target)  sassAsmInst(sass,GK110SASS_INST_JMP_ABS(target))
#define JMP_C(bank,k)  sassAsmInst(sass,GK110SASS_INST_JMP_ABS_C(bank,k))
#define JMX            #error "Todo"
#define JCAL(target)   sassAsmInst(sass,GK110SASS_INST_JCAL(target))

// Relative
#define BRA(target)    sassAsmInst(sass,GK110SASS_INST_BRA(target - sass->codePointer - 8))
#define BRX            #error "Todo"
#define CAL            #error "Todo"
#define PLONGJMP(target) sassAsmInst(sass,GK110SASS_INST_PLONGJMP(target - sass->codePointer - 8))
#define SSY(target)    sassAsmInst(sass,GK110SASS_INST_SSY(target - sass->codePointer - 8))
#define PBK            #error "Todo"
#define PCNT           #error "Todo"
#define PRET(target,inc) sassAsmInst(sass,GK110SASS_INST_PRET(target - sass->codePointer - 8,inc))

#define EXIT           #error "Todo"
#define LONGJML        #error "Todo"
#define RET            sassAsmInst(sass,GK110SASS_INST_RET)
#define KIL            #error "Todo"
#define RTT            sassAsmInst(sass,GK110SASS_INST_RTT)
#define RTT_TERMINATE  sassAsmInst(sass,GK110SASS_INST_RTT_TERMINATE)
#define BRK            #error "Todo"
#define CONT           #error "Todo"

#define SAM            #error "Todo"
#define RAM            #error "Todo"
#define BPT_PAUSE      sassAsmInst(sass,GK110SASS_INST_BPT(PAUSE,0))
#define BPT_TRAP(imm)  sassAsmInst(sass,GK110SASS_INST_BPT(TRAP,imm))
#define BPT_INT        sassAsmInst(sass,GK110SASS_INST_BPT(INT,0))
#define BPT_DRAIN      sassAsmInst(sass,GK110SASS_INST_BPT(DRAIN,0))

/* Page 9 Kepler 32I */
#define IMAD32I                     #error "Todo"
#define IADD32I(ra,rd,k)            sassAsmInst(sass,GK110SASS_INST_IADD32I(ra,rd,k))
#define IADD32I_CC(ra,rd,k)         sassAsmInst(sass,GK110SASS_INST_IADD32I_CC(ra,rd,k))
#define IADD32I_X(ra,rd,k)          sassAsmInst(sass,GK110SASS_INST_IADD32I_X(ra,rd,k))
#define IADD32I_NEGA_CC(ra,rd,k)    sassAsmInst(sass,GK110SASS_INST_IADD32I_NEGA_CC(ra,rd,k))
#define IMUL32I(ra,rd,k) sassAsmInst(sass,GK110SASS_INST_IMUL32I(ra,rd,k))
#define MOV32I(rd,k)   sassAsmInst(sass,GK110SASS_INST_MOV32I(rd,k))
#define FFMA32I        #error "Todo"
#define FADD32I        #error "Todo"
#define FMUL32I        #error "Todo"
#define LOP32I(lop,ra,rd,k)  sassAsmInst(sass,GK110SASS_INST_LOP32I(lop,ra,rd,k))
#define ISCADD32I      #error "Todo"

#define GETLMEMBASE(rd) sassAsmInst(sass,GK110SASS_INST_GETLMEMBASE(rd))
#define GETCRSPTR(rd) sassAsmInst(sass,GK110SASS_INST_GETCRSPTR(rd))

/* Used for Workaround for bug 840133 - If the sm instruction prefetcher isn't
   occupied with at least 320 bytes of nop's after a ret, it may be
   possible for it to take a branch to invalid instruction memory
   and trigger an MMU fault */
#define NOP_PAD(nop_count)                                                     \
do {                                                                           \
    NvU32 i;                                                                   \
    for (i = 0; i < nop_count; i++) {                                          \
        NOP;                                                                   \
    }                                                                          \
} while (0)

#endif // _GK11X_SASS_ASSEMBLER_H
