/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: gk10x_sass.h
 *
 *   Description:
 *       A partial set of Kepler GK10x SASS instruction macros. Primary
 *       client is the Kepler GK10x SASS Assembler.
 *
 ******************************************************************************/

#ifndef _GK10X_SASS_H
#define _GK10X_SASS_H

#define GK10XSASS_TOP6             63:58
#define    GK10XSASS_TOP6__SULDGA   0x35

#define GK10XSASS_BOT4              3:0
#define    GK10XSASS_BOT4__SULDGA   0x05

#define GK10XSASS_MASK_TOP6_BOT4          (BF_MASK(GK10XSASS_TOP6) + BF_MASK(GK10XSASS_BOT4))
#define GK10XSASS_INST_TOP6_BOT4(top,bot) (BF_FLD(GK10XSASS_TOP6,top) + BF_FLD(GK10XSASS_BOT4,bot))

#define GK10XSASS_PTRIDX    44:32

#define GK10XSASS_INST_TLD(rd, ra, ptrIdx) (0x9000000000000086ULL                  \
                                            + BF_FLD(FSASS_PRED,UNCOND)            \
                                            + BF_FLDV(FSASS_TEX_WRMASK,0x1)        \
                                            + BF_FLDV(FSASS_TEX_REGB,0x3f)         \
                                            + BF_FLDV(FSASS_TEX_DIM,0/*1D*/)       \
                                            + BF_FLDV(GK10XSASS_PTRIDX,ptrIdx)     \
                                            + BF_FLDV(FSASS_REGA,ra)               \
                                            + BF_FLDV(FSASS_TEX_REGD,rd))
#define GK10XSASS_INST_TEXDEPBAR (0xf000000000000006ULL + BF_FLD(FSASS_PRED,UNCOND))

#define GK10XSASS_B2RTYPE   50:49
#define     GK10XSASS_B2RTYPE__BAR     0
#define     GK10XSASS_B2RTYPE__RESULT  1
#define     GK10XSASS_B2RTYPE__WARP    2
#define     GK10XSASS_B2RTYPE__INVALID 3

#define GK10XSASS_INST_B2R(type, rd, barname) (FSASS_INST_B2R(rd, barname)         \
                                               + BF_FLD(FSASS_PRED,UNCOND)         \
                                               + BF_FLD(GK10XSASS_B2RTYPE, type))

#define GK10XSASS_BPT_MODE  16:14
#define GK10XSASS_BPT_MODE__DRAIN   0
#define GK10XSASS_BPT_MODE__CAL     1
#define GK10XSASS_BPT_MODE__PAUSE   2
#define GK10XSASS_BPT_MODE__TRAP    3
#define GK10XSASS_BPT_MODE__INT     4 // New on Kepler

#define GK10XSASS_INST_BPT(mode,imm) (0xD000000000000007ULL                        \
                                      + BF_FLD(GK10XSASS_BPT_MODE,mode)            \
                                      + BF_FLDV(FSASS_IMM20,imm))

#define GK10XSASS_INST_SULDGA_MASK   GK10XSASS_MASK_TOP6_BOT4
#define GK10XSASS_INST_SULDGA_OPCODE GK10XSASS_INST_TOP6_BOT4(SULDGA, SULDGA)

#endif
