/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: sass_assembler.h
 *
 *   Description:
 *       A Poor Man's inline SASS Assembler.
 *
 *
 ******************************************************************************/

#ifndef _SASS_ASSEMBLER_H
#define _SASS_ASSEMBLER_H

#include <cuos_platform.h>

/* Use a custom inline keyword because:
 * 1) Want to keep this independent of nytypes.h
 * 2) Re-defining "inline" causes build problems with gpgpucomp
 */
#if cuosOsIsWindows()
#define SASS_INLINE __inline
#else
#define SASS_INLINE inline
#endif

/* We try to be as generic as possible, but cuda_stdint.h solves the
   problem of not having stdint.h on certain Windows platforms and
   cuda.h gives us convenient error codes. */
#include <cuda.h>
#include <cuda_stdint.h>

/* This is the standard two-pass assembler. The source code is
   embedded in the function pass.

   A trivial example:

   SassCodeAddr LOOP;
   void fill(Sass_t sass) {
      MOV32I(R1, 0x10000);
    sassDefineLabel(&LOOP);
      ST(R1,0,RZ);
      ADDI(R1,R1,4);
      BRA(LOOP);
   }

   NOTE! the macros expect sass to be defined in the scope.
*/
#define SASS_MAX_LABELS          32
#define SASS_MAX_LABEL_LENGTH   128

typedef uint32_t SassCodeAddr;

typedef struct SassSymtab_st {
    uint32_t index;
    struct {
        const char* symName;
        SassCodeAddr offset;
    } symEntry[SASS_MAX_LABELS];
} SassSymtab;

typedef struct Sass_st {
    uint64_t *bufferStart;
    uint64_t *bufferPointer; /* Next location in buffer */
    uint64_t *bufferEnd;
    SassCodeAddr codePointer;
    SassSymtab *symTab;
    uint32_t needsPadding;
    uint32_t boundarySize;
    uint32_t padSize;
    uint64_t padDefault;
} *Sass_t;

CUresult sass_assemble(void (*pass)(Sass_t, void *), void *passArgs, void *buf, size_t bufSize, size_t *usedSize, SassSymtab *symTab, uint32_t sm_major, uint32_t sm_minor);
CUresult sass_symbol_offset(uint64_t *labelOffset, const char *labelName, SassSymtab *symTab);
#ifdef __linux__
void sass_disassemble(const void *buf, size_t bufSize, const char *cubinHeader);
void dumpCubin(char *name, const uint32_t *code, size_t codeSize, uint32_t sm_ver);
void dumpCubinRaw(char *name, const uint64_t *code, size_t codeSize);
#endif

static SASS_INLINE void sassBegin(Sass_t sass,
                                  SassCodeAddr origin,
                                  uint64_t *codeBuffer,
                                  size_t codeBufferSize,
                                  SassSymtab *symTab,
                                  uint32_t major,
                                  uint32_t minor)
{
    sass->bufferStart   = codeBuffer;
    sass->bufferPointer = codeBuffer;
    sass->bufferEnd     = codeBuffer + codeBufferSize;
    sass->codePointer   = origin;
    sass->symTab        = symTab;

    sass->needsPadding = 0;
    if (major == 5 && minor == 0) {
        sass->needsPadding = 1;
        sass->boundarySize = 32;
        sass->padSize = 8;
        /* On GM10x, force a default opex. This corresponds to the opex:
           "?OFF_DECK_DRAIN" for all 3 instructions in the unified format */
        sass->padDefault = 0x001F8000FC0007E0ULL;
    }

    if (sass->needsPadding && !(sass->codePointer % sass->boundarySize)) {
        *sass->bufferPointer = sass->padDefault;
        ++sass->bufferPointer;
        sass->codePointer += sass->padSize;
    }
}

static SASS_INLINE void sassEnd(Sass_t sass,
                                SassCodeAddr *endPC,
                                size_t *size)
{
    *endPC = sass->codePointer;
    *size  = (uintptr_t) sass->bufferPointer - (uintptr_t) sass->bufferStart;
}

static SASS_INLINE void sassDefineLabel(Sass_t sass, SassCodeAddr *label,
                                        const char *labelName)
{
    SassSymtab *symTab;
    uint32_t symTabIdx;
    SassCodeAddr codeAddr;

    codeAddr = sass->codePointer;
    // Compensate for padding early
    if (sass->needsPadding && !(codeAddr % sass->boundarySize)) {
        codeAddr += sass->padSize;
    }

    // Set the value of the static variable
    *label = codeAddr;

    // If no symbol table was passed in, record no symbol offsets
    symTab = sass->symTab;
    if (!symTab)
        return;

    symTabIdx = symTab->index;

    // If out of space, drop extra labels
    if (symTabIdx >= SASS_MAX_LABELS)
        return;

    symTab->symEntry[symTabIdx].symName = labelName;
    symTab->symEntry[symTabIdx].offset = *label;
    symTab->index++;
}

static SASS_INLINE void sassAsmInst(Sass_t sass, uint64_t inst)
{
    if (sass->needsPadding && !(sass->codePointer % sass->boundarySize)) {
        *sass->bufferPointer = sass->padDefault;
        ++sass->bufferPointer;
        sass->codePointer += sass->padSize;
    }

    if (sass->bufferPointer < sass->bufferEnd)
        *sass->bufferPointer = inst;

    ++sass->bufferPointer;
    sass->codePointer += 8;
    if (sass->needsPadding && !(sass->codePointer % sass->boundarySize)) {
        *sass->bufferPointer = sass->padDefault;
        ++sass->bufferPointer;
        sass->codePointer += sass->padSize;
    }
}

/* Modify the given field of an instruction (predicates, condition codes) */
static SASS_INLINE void sassModifyLastInst(Sass_t sass, uint64_t mask, uint64_t newVal)
{
    uint64_t *prevInst = NULL;
    uint64_t offset = (uint64_t)(sass->codePointer - 8);

    prevInst = &sass->bufferPointer[-1];
    if (sass->needsPadding && !(offset % sass->boundarySize))
        prevInst = prevInst - (sass->padSize / sizeof(*prevInst));

    *prevInst = (*prevInst & ~mask) + newVal;
}

#define LABEL(l) l

#define DEFLABEL(l) sassDefineLabel(sass, &l, #l)

#define CREATE_LABEL_BEGIN
#define CREATE_LABEL(l) static SassCodeAddr l = 0;
#define CREATE_LABEL_END


#endif
