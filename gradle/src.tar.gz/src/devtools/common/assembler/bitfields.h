/*
 * Copyright 2007-2013 NVIDIA Corporation.  All rights reserved.
 *
 * NOTICE TO USER:
 *
 * This source code is subject to NVIDIA ownership rights under U.S. and
 * international Copyright laws.  Users and possessors of this source code
 * are hereby granted a nonexclusive, royalty-free license to use this code
 * in individual and commercial software.
 *
 * NVIDIA MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS SOURCE
 * CODE FOR ANY PURPOSE.  IT IS PROVIDED "AS IS" WITHOUT EXPRESS OR
 * IMPLIED WARRANTY OF ANY KIND.  NVIDIA DISCLAIMS ALL WARRANTIES WITH
 * REGARD TO THIS SOURCE CODE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * IN NO EVENT SHALL NVIDIA BE LIABLE FOR ANY SPECIAL, INDIRECT, INCIDENTAL,
 * OR CONSEQUENTIAL DAMAGES, OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
 * OF USE, DATA OR PROFITS,  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE
 * OR OTHER TORTIOUS ACTION,  ARISING OUT OF OR IN CONNECTION WITH THE USE
 * OR PERFORMANCE OF THIS SOURCE CODE.
 *
 * U.S. Government End Users.   This source code is a "commercial item" as
 * that term is defined at  48 C.F.R. 2.101 (OCT 1995), consisting  of
 * "commercial computer  software"  and "commercial computer software
 * documentation" as such terms are  used in 48 C.F.R. 12.212 (SEPT 1995)
 * and is provided to the U.S. Government only as a commercial end item.
 * Consistent with 48 C.F.R.12.212 and 48 C.F.R. 227.7202-1 through
 * 227.7202-4 (JUNE 1995), all U.S. Government End Users acquire the
 * source code with only those rights set forth herein.
 *
 * Any use of this source code in individual and commercial software must
 * include, in the user documentation and internal comments to the code,
 * the above Disclaimer and U.S. Government End Users Notice.
 */

/******************************************************************************
 *
 *   Module: bitfields.h
 *
 *   Description:
 *       A handy set of macros
 *
 ******************************************************************************/

#ifndef _BITFIELDS_H
#define _BITFIELDS_H

/* Bitfield manipulations */
#define BF_LO(fld)          (0?fld) // BF_LO(HI:LO) == LO
#define BF_HI(fld)          (1?fld) // BF_HI(HI:LO) == HI
// ~0ULL << 4 = 0b111..1111110000
// ~0ULL << 9 = 0b111..1000000000
// ^          = 0b000..0111110000
#define BF_RUN(n)           (~0ULL << (n))

// Create a bit mask from a hi:lo pair
#define BF_MASK(fld)        (BF_RUN(BF_HI(fld)) << 1 ^ BF_RUN(BF_LO(fld)))

// Shifts a value into its bitfield
#define BF_FLD(fld,v)       ((uint64_t)(fld##__##v) << BF_LO(fld))
#define BF_FLDV(fld,v)      (BF_MASK(fld) & ((uint64_t)(v)) << BF_LO(fld))

// Shifts bitfield down
#define BF_GET(fld,v)       ((uint32_t) ((BF_MASK(fld) & (v)) >> BF_LO(fld)))

// Copy the value of a bitfield from one word to another
#define BF_COPY(fld,from,to)(((to) & ~BF_MASK(fld)) | ((from) & BF_MASK(fld)))

#define BF_SETFLDV(o,f,fv) ((o) = ((o) &~ BF_MASK(f)) + BF_FLDV(f, fv))

#endif
