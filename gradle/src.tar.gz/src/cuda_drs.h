/*
 * Copyright 1993-2013 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef __cuda_drs_h__
#define __cuda_drs_h__

#ifdef __cplusplus
extern "C" {            /* Assume C declarations for C++ */
#endif  /* __cplusplus */

#if defined (NVDRSLIB_WIN)
  // Cuda DRS specific assert - exit removed since assert isnlt fatal, DRS just gets disabled
#ifdef DEBUG
#define DRS_ASSERT(exp) \
    do { \
        if ( ! (exp) ) { \
            cuosFprintf (cuosGetStderr(), "Assertion failed (%s in " __FILE__ ", line %d): condition %s not true\n", __FUNCTION__, __LINE__, #exp ); \
            cuosFflush( cuosGetStderr() ); \
            cuosDebugBreak();\
        } \
    } while (0)
#else
#define DRS_ASSERT(exp) (void)(exp)
#endif //DEBUG
#endif // NVDRSLIB_WIN

void cuiAppProfileInit(void);
void cuiAppProfileDestroy(void);
NvBool cuiAppProfileGetValue(const char *name, NvU32 id, NvU32 defaultValue, NvU32 *value);

#ifdef __cplusplus
} /* End of extern "C" { */
#endif  /* __cplusplus */

#endif /* __cuda_drs_h__ */
