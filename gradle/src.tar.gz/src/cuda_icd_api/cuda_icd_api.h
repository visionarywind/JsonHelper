/*
 * Copyright 1993-2014 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

/******************************************************************************
*
*   Module: CUDA_ICD
*
*   Description:
*       wrappers to access any of the cuda functions 
*
******************************************************************************/
#ifndef __cuda_icd_api_h__
#define __cuda_icd_api_h__
#include <stdio.h>
#include <cuos.h> // call the function cuosGetProcAddress
#define CU_INIT_UUID
#include "generated_etbl_cuda_icd.h" //This file is auto generated under the //built_dir/
#endif
