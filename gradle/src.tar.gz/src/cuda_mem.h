/*
 * Copyright 1993-2009 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

/******************************************************************************
*
*   Module: cuda_mem.h
*
*   Description:
*       Internal header file for memory abstraction functions/structures.
*
******************************************************************************/

#ifndef __cuda_mem_h__
#define __cuda_mem_h__

#include "cuda_mem_enums.h"

/**
 *
 * Headers required for structures and functions
 *
 */

#include "nvtypes.h"
#include "nvgputypes.h"
#include "nvSurfaceFormats.h"
#include "nvBlockLinear.h"

#include "cuda.h"
#include "cuos.h"
#include "cuda_structs.h"

#include "map.h"
#include "heap.h"

#include "peermap.h"

#include "wddm_mem.h"
#include "rm_mem.h"
#include "mrm_mem.h"
#include "amod_mem.h"
#include "mps_globals.h"
#include "cuda_nvrm_common.h"
#include "cuda_nvcommon_surface.h"

typedef struct CUmemmgrDMAL_st    CUmemmgrDMAL;
typedef struct CUmemrangeMPS_st   CUmemrangeMPS;
typedef struct CUmemobjOwnershipChangeParams_st CUmemobjOwnershipChangeParams;

#define CU_DEVICE_VADDR_SIZE_40_BIT (1ULL << 40ULL) // 40bit

#define CU_DEVICE_VADDR_SIZE_49_BIT (1ULL << 49ULL) // 49bit

#define CU_DEVICE_VADDR_BASE_33_BIT (1ULL << 33ULL) 

#define CU_DEVICE_VADDR_NON_UVA_BASE_40_BIT   (1ULL << 33ULL) 
#define CU_DEVICE_VADDR_NON_UVA_SIZE_40_BIT   (1ULL << 31ULL) // 2G, same size as in UVA 40-bit pre-reservation.
#define CU_DEVICE_VADDR_NON_UVA_ALIGN_40_BIT  (1ULL << 21ULL) // 2M 

// __TEMP_WAR__ bug 1849801
// The max possible VA that the OS allocates on our behalf is limited based on the CPU
// architecture as shown:
// x86 - 2^47 - 1
// ARM - 2^48 - 1
// P8  - 2^46 - 1
// P9  - 2^49 - 1
// When using UVA, we always reserve on the host first, which guarantees that a valid
// address on the GPU. However, when not using UVA, we must pick a GPU address that falls
// within the CPU's range.
// The reason for doing this is because the CPU requires all addresses to be canonical
// (see https://en.wikipedia.org/wiki/X86-64#Canonical_form_addresses for details)
// and the SM enforces whatever the CPU requires (see //hw/nvgpu/manuals/pri_smc.ref,
// "OOR_ADDR_CHECK_MODE"). So if RM is allowed to pick an address anywhere in the GPU's
// 49-bit VA range, then an address could be picked that's outside the CPU's valid range,
// resulting in a non-canonical address.
// Note that this limit should depend on the actual CPU architecture in use. Unfortunately
// it cannot be determined at compile time because P8 and P9 have different ranges, but
// there's only one driver build for them. So we will need to check at runtime. Until we
// add that functionality, take the lowest common denominator.
#define CU_DEVICE_PASCAL_PLUS_VADDR_NON_UVA_LIMIT   (1ULL << 46)

/**
 *
 * Structure definitions and function prototypes
 *
 */

#ifdef __cplusplus
extern "C" {   // Assume C declarations for C++
#endif  // __cplusplus

static NvBool memflagsMapDevicePtr(CUmemflagsMapDevice flagsMapDevice)
{
    return (flagsMapDevice == CU_MEM_MAP_DEVICE_PTR
         || flagsMapDevice == CU_MEM_MAP_DEVICE_PTR_FORCE_32_BIT
         || flagsMapDevice == CU_MEM_MAP_DEVICE_PTR_FORCE_40_BIT);
}

// note that the number of bits per flag is bloated by one because
// bit fields are sign-extended, and the signedness of enums is
// undefined (and in practice, signed, leading to a location of
// of 0x2 being sign-extended to 0xfffffffe)
struct CUmemflags_st {
    CUmemflagsLocation    location        : CU_MEM_LOCATION_BITS+1;
    CUmemflagsCacheHost   cacheHost       : CU_MEM_CACHE_HOST_BITS+1;
    CUmemflagsCacheDevice cacheDevice     : CU_MEM_CACHE_DEVICE_BITS+1;
    CUmemflagsType        type            : CU_MEM_TYPE_BITS+1;
    CUmemflagsLayout      layout          : CU_MEM_LAYOUT_BITS+1;
    NvU32                 noAddrMap       : 1; // No address to CUmemobj mapping
    CUmemflagsDepth       depth           : CU_MEM_DEPTH_BITS+1;
    NvBool                isUserPortable  : 1; // Did the *user* request this be portable (may be auto-portable in UVA w/o user request)
    NvBool                isIOMem         : 1; // *user* buffer is actually a user-space mapping of a memory-mapped I/O space belonging to a third-party (PCIe) device (introduced in chips_a with CL 18501319)
    CUmemflagsMapHost     mapHost         : CU_MEM_MAP_HOST_BITS+1;
    CUmemflagsMapDevice   mapDevice       : CU_MEM_MAP_DEVICE_BITS+1;
    CUmemflagsOwner       owner           : CU_MEM_OWNER_BITS+1;
    CUmemflagsSharing     sharing         : CU_MEM_SHARING_BITS+1;
    NvBool                internalMapping : 1; //  internal mapping, used only for CU_MEM_SHARING_CUDA_MEMOBJ
    CUmemflagsAccess      access          : CU_MEM_ACCESS_BITS+1;
    CUmemflagsVisibility  visibility      : CU_MEM_VISIBILITY_BITS+1; // default visibility specified at memobj alloc
    NvU32                 noSuballoc      : 1; // Do not suballocate
    NvBool                fixedDevVaddr   : 1; // Use a fixed device virtual address (APIC only)
    NvBool                fixedDevPhysAddr: 1; // Use a fixed device physical address
    NvBool                exportForShm    : 1; // Allocate using OS shared memory
    NvU32                 forcedToHost    : 1;
    NvU32                 forcedToDevice  : 1;
    NvU32                 lazyMapDevice   : 1; // map to device on access using replayable faults.
    CUmemflagsApi         apiSource       : CU_MEM_API_BITS+1;
    NvBool                userOwnsData    : 1; // For apiSource == 0 allocations containing user-owned data (need to save/restore for replay)
    CUmemflagsPageSize    pageSize        : CU_MEM_PAGE_SIZE_BITS+1;
    NvBool                canSkipPaging   : 1; // Allow to skip memmgrTriggerPaging() if necessary. See memmgrTriggerPagingWDDM()
    NvBool                forceNewMapping : 1; // Map at a new VA and don't use the source memblock's VA (if one exists)
    NvBool                forcePinning    : 1; // Force the memory to be pinned (used only for pinning host registered memory on ATS systems)
    NvBool                isLoopback      : 1; // Use P2P loopback (used on NVLink by MODS emulating P2P on a single GPU)
    NvBool                isFromMpsClient : 1; // Set to 1 on server when the memblock is allocated for client
    NvBool                isPeersyncAlias : 1; // Hack to identify virtual aliases created for peersync. This should be replaced by a general method to avoid RM RegisterVidmem calls for aliases memblocks. Bug 1808818
    CUmemflagsL3CacheDevice l3CacheDevice : CU_MEM_L3_CACHE_DEVICE_BITS+1; // Enable L3 Cache for device memory
    CUmemflagsCompressionMode compressionMode : CU_MEM_COMPRESSION_MODE_BITS+1;
    CUmemflagsHandleType  handleTypes : CU_MEM_FLAGS_HANDLE_TYPE_BITS+1;  // Set to the requested and created handle types for the allocation (defaults to none)
    NvBool                isNonDedicated  : 1; // Set for externally allocated memory that's not dedicated to a single resource (ex., D3D12 heap, Vulkan non-dedicated memory)
    NvBool                deleteOnSourceFreed : 1; // For shared mapping made on the primary memmgr, indicates that the mapping must be deleted
    NvBool                forceCtxSyncOnFree : 1; // Synchronize all contexts on free
    NvBool                externallyManagedVA : 1; // VA bound to this memobj is managed externally and should not be freed when the memobj is freed
    NvBool                forceSingleAllocation : 1; // This memobj's memblock must have only one subblock
    NvBool                restrictedVaRange : 1;
    NvBool                isForEGLCrossSystem : 1; // This memobj will be copied across system over DMA/SOCKET, since EGL only understands NvMemHandles it should be allocated using NvRmAlloc.
};

struct CUblockLinearInfo_st {
    NV_SURFACE_FORMAT format;
    NvBlockLinearImageInfo blInfo;
    NvU32 flags;
    NvU32 width;
    NvU32 height;
    NvU32 depth;
    NvU32 pitch;
};

struct CUmemparams_st {
    // User-specified fixed physical address (only relevant if flag fixedDevVaddr is set)
    NvU64 physaddr;
    // User-specified fixed device VA (only relevant if flag fixedDevPhysAddr is set, APIC only)  
    NvU64 devvaddr;
    // User-specified lower limit for device VA (only relevant if flag restrictedVaRange is set)
    NvU64 vaStart;
    // User-specified upper limit for device VA (only relevant if flag restrictedVaRange is set)
    NvU64 vaEnd;
};

struct CUmembin_st {
    NvU64 size;   // Size in bytes of the bin
};

struct CUmembins_st {
    NvU32 count;
    NvU32 seed;
    CUmembin (*binfunc)(CUmembin* membin);
    CUmembin *bins;
};

// Generic linked-list element type to track allocated 
// and free memory regions of a memblock
struct CUmemregion_st
{
	struct CUmemregion_st *prev;
	struct CUmemregion_st *next;
	NvBool isAllocated;
};

// Shared memory allocation type
struct CUmemshare_st {
    NvU64 devvaddr;   // Device virtual address
    NvU64 hostvaddr;  // Host virtual address
    NvU64 offset;     // Offset from base allocation to map
    NvU64 memobjOffset; // requested memobj offset within shared memblock
    NvU64 blocksize;  // Size of parent block for shared allocation
    NvU64 orighostvaddr; // Original host VA, non-zero only if hostvaddr was fudged
    NvU64 orighostsize; // Original host size, non-zero only if hostvaddr was fudged

    // The source from another context for shared memobjs
    CUmemobj   *sourceMemobj;   // This is always NULL in CUmemblock::memdesc (only used in memobjAlloc)
    CUmemblock *sourceMemblock;
    CUdev      *sourceDevice;   // The source device for interop and cross-process P2P allocations.

    // Key for OS shared memory region (used by CU_MEM_SHARING_SHM)
    cuosShmKey shmKey;

    // IPC source memblock serial (to determine whether suballocation should be allowed)
    NvU64 sourceMemblockSerial;

    union { // DMAL-specific shared memory state
        CUmemshareRM        rm;
        CUmemshareMRM       mrm;
        CUmemshareAMOD      amod;
        CUmemshareWDDM      wddm;
        CUmemshareMPS       mps;
    } dm;
};

struct CUmemrange_st {
    CUmemrange *prev;
    CUmemrange *next;

    NvU64 vaddr; // Base virtual address of the range
    NvU64 size;  // Size in bytes of the range

    // DMAL-specific memory range state
    struct {
        CUmemrangeRM        *rm;
        CUmemrangeMRM       *mrm;
        CUmemrangeAMOD      *amod;
        CUmemrangeWDDM      *wddm;
        CUmemrangeMPS       *mps;
    } dm;

    CUmemmgr *memmgr;
    CUheapobj *heapobj;
    NvBool dirty; // Dirty bit for range updates
    NvBool reservedThroughUva; // VA range was reserved through UVA manager
};

struct CUmemdesc_st {
    CUmemflags        flags;
    CUblockLinearInfo blInfo;
    CUmemshare        memshare;
    CUmemparams       params;
    CUmemrange*       memrange;
    NvU64             uvaAlignment;     // Alignment of unified virtual address (must be power of 2)
    CUnvchannel*      pChannel;         // Channel associated to the memory (only used for allocation tied to a channel, like Gpfifo)

    union { // DMAL-specific state
        CUmemdescWDDM wddm;
        CUmemdescAMOD amod;
        CUmemdescMPS mps;
        CUmemdescMRM mrm;
    } dm;
};

struct CUmemmgrinfo_st {
    float vmfrag;  // Device VAS fragmentation
    NvU64 vmtotal; // Total device virtual memory
    NvU64 vmfree;  // Free device virtual memory
    NvU64 smtotal; // Total host virtual memory
    NvU64 smfree;  // Free host virtual memory
    NvU64 cmtotal; // Total cached system memory
    NvU64 cmfree;  // Free cached system memory
    NvU64 pmtotal; // Total device physical memory
    NvU64 pmfree;  // Free device physical memory
};

struct CUmeminfo_st {
    float frag;     // Fragmentation of parent block heap
    NvU64 physaddr; // Physical address
    NvU32 ptekind;  // PTE kind bits
    NvU32 stride;   // Partition stride for allocation
};

struct CUmemobjOwnershipChangeParams_st {
    CUmemobj *memobj;         // ptr to memobj
    NvBool retainHostAccess;  // retain host accessibility even if host doesn't own
    NvBool makeHostOwner;     // !makeHostOwner means take ownership away from host
    NvBool isHostCurrentOwner;// does the host own the memobj or not.
    NvBool socRegister;       // on SoC track a new region, ownership change is in notify call.
    NvBool socUnregister;     // on SoC stop tracking a region, ownership change is in notify call.
    NvBool socHostPrefetch;   // on SoC prefetch on Host to avoid CPU page faults
};

#include "generated_memmgr_dmal.h"

#ifdef __cplusplus
}
#endif  // __cplusplus

#endif //__cuda_mem_h__


