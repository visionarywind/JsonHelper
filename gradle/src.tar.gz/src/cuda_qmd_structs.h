
/*
 * Copyright 1993-2019 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

#ifndef __cuda_qmd_structs_h__
#define __cuda_qmd_structs_h__


#include "nvtypes.h"

typedef struct CUqmdDesc_st CUqmdDesc;
typedef struct CUqmdSemaphoreRelease_st CUqmdSemaphoreRelease;
typedef struct CUqmdConstantBuffer_st CUqmdConstantBuffer;
typedef struct CUqmdDependentQmd_st CUqmdDependentQmd;

#define CU_MAX_QMD_SEMAPHORE_RELEASE_COUNT (3)
#define CU_MAX_QMD_DEPENDENT_QMD_COUNT (2)
#define CU_MAX_CONSTANT_BUFFER_COUNT (8)

struct CUqmdSemaphoreRelease_st
{
    NvBool   enabled;
    NvU64    address;
    NvU64    payload;
    NvBool   useReduction;
    NvU32    flags;
};

struct CUqmdConstantBuffer_st
{
    NvBool   valid;
    NvU64    address;
    NvU64    size;
    NvBool   invalidate;
};

typedef enum CUqmdPcasAction_enum
{
    CUI_QMD_PCAS_ACTION_INVALIDATE               = 0x1,
    CUI_QMD_PCAS_ACTION_SCHEDULE                 = 0x2,
    CUI_QMD_PCAS_ACTION_COPY_HW_FIELDS           = 0x4,
    CUI_QMD_PCAS_ACTION_PREFETCH                 = 0x8
} CUqmdPcasAction;

struct CUqmdDependentQmd_st
{
    NvBool              enabled;
    NvU64               address;
    CUqmdPcasAction     action;
};

typedef enum CUqmdMembarType_enum
{
    CUI_QMD_FE_MEMBAR_MASK = 0xF0,
    CUI_QMD_FE_MEMBAR_NONE = 0x00,
    CUI_QMD_FE_MEMBAR_SYS  = 0x10,

    CUI_QMD_CWD_MEMBAR_MASK   = 0xF00,
    CUI_QMD_CWD_MEMBAR_NONE   = 0x000,
    CUI_QMD_CWD_L1_MEMBAR_SYS = 0x100,
    CUI_QMD_CWD_L1_MEMBAR     = 0x200,
} CUqmdMembarType;

struct CUqmdDesc_st
{
    // Grid dimension (number of blocks)
    NvU32 gridWidth;
    NvU32 gridHeight;
    NvU32 gridDepth;

    // Number of thread per block
    NvU32 threadBlockWidth;
    NvU32 threadBlockHeight;
    NvU32 threadBlockDepth;

    // Pointer to the first address of the program
    NvU64 programLaunchPc;

    // Information on how to prefetch program data into the instruction cache (Turing+)
    NvU64 programPrefetchAddress;
    NvU32 programPrefetchSize;


    // Constant buffers info
    CUqmdConstantBuffer constantBuffer[CU_MAX_CONSTANT_BUFFER_COUNT];

    // Number of per-thread registers allocated for the program.
    NvU16 registerCount;
    // Number of barrier per CTA
    NvU16 barrierCount;

    // Bitmask of disabled logical SM (post-floorswept) or TPC (2 SMs groups) for Volta+.
    NvU64 smDisableMask;

    NvU32 sharedMemorySize;

    NvU8 sassVersionMajor;
    NvU8 sassVersionMinor;

    // size of the per-thread memory for variable storage
    NvU64 localMemoryHighSize;
    // size of the per-thread memory for data stack
    NvU64 localMemoryLowSize;
    // size of the per-thread crs (Call Return Stack) for Pascal-
    NvU64 localMemoryCrsSize;

    // set the priority group associated to this QMD.
    NvU8 groupId;
    // when set to true the QMD will be put at the top of the queue
    // for its specified priority group (i.e. it should be the next
    // one to be scheduled when its priority group will be picked)
    NvBool addToHeadOfGroupList;

    // The following fields indicates which caches must be invalidated
    // when the task is launched by SKED
    NvBool invalidateTextureHeaderCacheAtLaunch;
    NvBool invalidateTextureSamplerCacheAtLaunch;
    NvBool invalidateTextureDataCacheAtLaunch;
    NvBool invalidateShaderDataCacheAtLaunch;
    NvBool invalidateInstructionCacheAtLaunch;
    NvBool invalidateShaderConstantCacheAtLaunch;

    // When set to true only Scheduling PCAS can put this QMD in the scheduling queue.
    // This means that other PCAS like the copy PCAS that happens in an IQ2M will put
    // the QMD in the sched cache but will not add the QMD to the scheduling queue.
    NvBool requireSchedulingPcas;

    // Used to configure QMD chaining
    CUqmdDependentQmd dependentQmd[CU_MAX_QMD_DEPENDENT_QMD_COUNT];

    // Indicates what kind of semaphore must be released when this QMD will completes
    CUqmdSemaphoreRelease semaphoreRelease[CU_MAX_QMD_SEMAPHORE_RELEASE_COUNT];

    // Performance hint on some architecture:
    //    HW will assume that this specified number of CTA can fit
    //    at once on an empty SM and this without waiting for feedback
    //    to determine the free slots remaining on the SM.
    NvU64 hintFreeCtaSlotsOnAnEmptySm;

    NvBool smGlobalCaching;

    // For Volta+ indicates how to select and
    // how to configure an SM for shared memory / L1 usage.
    // The hardware will first look for an SM that has a configuration
    // that matches the range [minSmConfigurationSharedMemorySize, maxSmConfigurationSharedMemorySize]
    // if Hardware can't find any it will provision a new SM with using targetSmConfigurationSharedMemorySize
    NvU32 smConfigurationMinSharedMemorySize;
    NvU32 smConfigurationTargetSharedMemorySize;
    NvU32 smConfigurationMaxSharedMemorySize;

    CUqmdMembarType membar;

    // For Ampere GA10X+ It is possible to use a feature called
    // SM simultaneous compute and compte usually called SMSCC.
    // This feature is mainly designed to help with GPU utilization
    // and raytracing and more detail on the full behavior can be found
    // in bug: 2509750
    NvU32 ctaLaunchQueue;
    NvU32 occupancyThresholdWarp;
    NvU32 occupancyThresholdRegister;
    NvU32 occupancyThresholdSharedMem;
    NvU32 occupancyMaxWarp;
    NvU32 occupancyMaxRegister;
    NvU32 occupancyMaxSharedMem;

};

#endif // __cuda_qmd_structs_h__