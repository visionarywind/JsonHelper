/*
 * Copyright 2017 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

/******************************************************************************
*
*   Module: cuda_internal_eglsync.h
*
*   Description:
*       Internal header file for compute EGLSync interop interface.
*
******************************************************************************/

#ifndef __cuda_internal_eglsync_h__
#define __cuda_internal_eglsync_h__

#include "cudaEGL.h"
#include "mobile_common.h"
#ifdef __cplusplus
extern "C" {
#endif
#if cuiIsEglSyncSupported()
CUresult cuiEventCreateFromEGLSync(CUctx *ctx, CUevent *ppEvent, EGLSyncKHR eglSync, unsigned int Flags);
CUresult cuiEGLSyncGetClientFence(void *clientAPIEvent, NvRmSync **fenceOut);
#endif
#ifdef __cplusplus
}
#endif
#endif
