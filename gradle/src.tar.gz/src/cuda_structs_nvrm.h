/*
 * Copyright 2014 by NVIDIA Corporation.  All rights reserved.  All
 * information contained herein is proprietary and confidential to NVIDIA
 * Corporation.  Any use, reproduction, or disclosure without the written
 * permission of NVIDIA Corporation is prohibited.
 */

/******************************************************************************
*
*   Module: cuda_structs_nvrm.h
*
*   Description:
*       Internal structures for compute driver architecture.
*
******************************************************************************/


#ifndef __cuda_structs_nvrm_h__
#define __cuda_structs_nvrm_h__

#include "interop.h"
#include "cuda_nvrm_common.h"
#include "cuda_nvcommon_surface.h"
#include "cuieglcommon.h"
#include "cuictx.h"
#include "cuda_internal.h"
#include "cuda_structs_eglstream.h"
#include "cuistream.h"
struct CUIgraphicsClientNVRM_st
{
    CUcommonSurfaces surfs;
};

struct CUIgraphicsResourceRegisterParamsNVRM_st
{
    CUcommonSurfaces surfs;
    unsigned int flags;
};

#ifdef __cplusplus
struct CUNVRMobject : public CUobject {
protected:
    NvU32 m_flags;              // User map flags
    bool m_mapped        : 1;      // Object is currently mapped
    bool m_copy          : 1;   // flag to check if we have to copy frame between igpu to dgpu
    CUmemobj *m_memobj[MAX_PLANES], *m_memobj_dgpu[MAX_PLANES];          // local copy, if required
    CUcommonSurfaces m_cuCmnSurfs;
    size_t m_size[MAX_PLANES];     // Size of buffer
    NvU32 m_bytesPerPixel[MAX_PLANES];
public:
    CUNVRMobject(CUIgraphicsClient *client, unsigned int flags, CUcommonSurfaces *cuCmnSurfs);
    virtual ~CUNVRMobject() {}

    virtual CUresult Register(CUIgraphicsClient *client) = 0;
    virtual CUresult Unregister(CUIgraphicsClient *client) = 0;

    virtual CUresult getMappedPointer(void **dPtr, size_t *size) = 0;
    virtual CUresult getArray(unsigned int level, unsigned int slice, CUarray *pArray) = 0;
    virtual CUresult getMappedEglFrame(CUeglFrame* eglFrame) = 0;
    virtual CUresult copyFrame(CUctx *ctx, CUstream *pStream);
    bool isMapped(void) { return m_mapped; }

    void SetMapFlags(unsigned int flags) { m_flags = flags; }
    NvU32 getMapFlags(void) { return m_flags; }
    CUresult FreeDupHandles(CUgraphicsResource resource);
};

class CUNVRMSurfPitch : public CUNVRMobject {
public:
    CUNVRMSurfPitch(CUIgraphicsClient *client, unsigned int flags, CUcommonSurfaces *cuCmnSurfs);
    ~CUNVRMSurfPitch() { }

    CUresult Register(CUIgraphicsClient *client);
    CUresult Unregister(CUIgraphicsClient *client);

    CUresult getMappedPointer(void **dPtr, size_t *size) {
        CU_ASSERT(isMapped());
        *dPtr = m_dPtr[0];
        *size = m_size[0];
        return CUDA_SUCCESS;
    }

    CUresult getMappedEglFrame(CUeglFrame* eglFrame) {
        *eglFrame = m_cueglFrame;
        return CUDA_SUCCESS;
    }

    CUresult getArray(unsigned int level, unsigned int slice, CUarray *pArray) {
        return CUDA_ERROR_NOT_MAPPED_AS_ARRAY;
    }

protected:

    void *m_dPtr[MAX_PLANES];      // GPU virtual address of mapping
    void *m_dPtr_dgpu[MAX_PLANES];
    CUeglFrame m_cueglFrame;
};

class CUNVRMSurfBL : public CUNVRMobject {
protected:
    CUarr *m_arrays;
    CUeglFrame m_cueglFrame;
public:
    CUNVRMSurfBL(CUIgraphicsClient *client, unsigned int flags, CUcommonSurfaces *cuCmnSurfs);
    ~CUNVRMSurfBL() { }

    CUresult Register(CUIgraphicsClient *client);
    CUresult Unregister(CUIgraphicsClient *client);

    CUresult getMappedPointer(void **dPtr, size_t *size) {
        return CUDA_ERROR_NOT_MAPPED_AS_POINTER;
    }

    CUresult getMappedEglFrame(CUeglFrame* eglFrame) {
        *eglFrame = m_cueglFrame;
        return CUDA_SUCCESS;
    }

    CUresult getArray(unsigned int level, unsigned int slice, CUarray *pArray);
};

#endif /* __cplusplus */

#endif /* __cuda_structs_nvrm_h_ */


